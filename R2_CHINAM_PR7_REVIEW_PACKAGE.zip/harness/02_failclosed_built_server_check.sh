#!/usr/bin/env bash
# R2 harness — bước CI mới (scripts/check-built-server-grok-extension.mjs) có fail-closed không?
# Dựng các thư mục .vercel/output giả (hàm máy chủ giả) rồi chạy script CỦA H lên từng cái.
# Kỳ vọng: mọi trường hợp hỏng => exit != 0; chỉ output thật => exit 0.
#
# Cách dùng: bash 02_failclosed_built_server_check.sh <checkout H> <.vercel/output thật> <thư mục làm việc>
set -u
H="$(cd "$1" && pwd -P)"
REAL_OUT="$2"
WORK="$3"
SCRIPT="$H/scripts/check-built-server-grok-extension.mjs"
rm -rf "$WORK" && mkdir -p "$WORK"
NEEDLE='https://grok.com/grok-app-builder/extensions.js'

mkfn() { # $1 = tên ca, stdin = nội dung index.mjs
  mkdir -p "$WORK/$1/functions/__server.func"
  cat >"$WORK/$1/functions/__server.func/index.mjs"
}

mkdir -p "$WORK/A_no_output_dir_contents"            # thư mục rỗng, không có hàm
mkdir -p "$WORK/B_func_dir_without_index/functions/__server.func"
mkfn C_import_throws <<'EOF'
throw new Error("boom at import");
EOF
mkfn D_no_fetch <<'EOF'
export default { notFetch() {} };
EOF
mkfn E_status_500 <<EOF
export default { fetch: () => new Response("<html><head></head><body>err</body></html>", { status: 500, headers: { "content-type": "text/html" } }) };
EOF
mkfn F_empty_200 <<'EOF'
export default { fetch: () => new Response("", { status: 200, headers: { "content-type": "text/html" } }) };
EOF
mkfn G_always_injects <<EOF
export default { fetch: () => new Response('<html><head><script src="$NEEDLE" defer></script></head><body>x</body></html>', { status: 200, headers: { "content-type": "text/html" } }) };
EOF
mkfn H_never_injects <<'EOF'
export default { fetch: () => new Response("<html><head></head><body>x</body></html>", { status: 200, headers: { "content-type": "text/html" } }) };
EOF
mkfn I_respects_env <<EOF
export default { fetch: () => new Response(process.env.VITE_GROK_EXTENSIONS === "0" ? "<html><head></head><body>x</body></html>" : '<html><head><script src="$NEEDLE"></script></head><body>x</body></html>', { status: 200, headers: { "content-type": "text/html" } }) };
EOF
mkfn J_stdout_noise_after_result <<'EOF'
setTimeout(() => process.stdout.write("\nnoise-after"), 0);
export default { fetch: async () => { await new Promise(r => setTimeout(r, 5)); return new Response(process.env.VITE_GROK_EXTENSIONS === "0" ? "<html>x</html>" : "<html>grok-app-builder/extensions.js</html>", { status: 200 }); } };
EOF
mkfn K_hangs_forever <<'EOF'
export default { fetch: () => new Promise(() => { setInterval(() => {}, 1000); }) };
EOF

run_case() {
  local name="$1" dir="$2"
  local start end rc out
  start=$(date +%s)
  out="$(node "$SCRIPT" "$dir" 2>&1)"; rc=$?
  end=$(date +%s)
  printf '=== %s\n%s\nEXIT=%s DURATION_S=%s\n' "$name" "$(printf '%s' "$out" | tail -4 | cut -c1-300)" "$rc" "$((end-start))"
}

for d in A_no_output_dir_contents B_func_dir_without_index C_import_throws D_no_fetch E_status_500 F_empty_200 \
         G_always_injects H_never_injects I_respects_env J_stdout_noise_after_result K_hangs_forever; do
  run_case "$d" "$WORK/$d"
done
run_case "L_nonexistent_path" "$WORK/khong-ton-tai"
run_case "M_real_clean_build_output" "$REAL_OUT"

# N: gọi script qua đường dẫn có symlink (import.meta.url bị realpath, process.argv[1] thì không)
ln -s "$H" "$WORK/H_symlink"
start=$(date +%s); out="$(node "$WORK/H_symlink/scripts/check-built-server-grok-extension.mjs" "$WORK/A_no_output_dir_contents" 2>&1)"; rc=$?; end=$(date +%s)
printf '=== %s\n[stdout+stderr: %s byte] %s\nEXIT=%s DURATION_S=%s\n' "N_symlinked_script_path_on_EMPTY_output" "${#out}" "$out" "$rc" "$((end-start))"
