#!/usr/bin/env bash
# R2 harness — việc (4): đổi thư mục build sạch từ mktemp sang $RUNNER_TEMP có làm yếu phép kiểm cũ không?
# Trích thân bước "Build kiểu Vercel từ mã nguồn (clean checkout)" từ workflow của M và của H
# (bằng git show, không chép tay), chạy dưới `bash -e` (giống shell mặc định của GitHub Actions)
# trong ba tình huống:
#   T1: mã nguồn H bình thường                           -> cả hai phải PASS
#   T2: commit có .vercel/output bị track (đầu ra cũ)     -> cả hai phải FAIL ở guard "stale prebuilt output"
#   T3: (chỉ H) thư mục $RUNNER_TEMP/chinam-clean-vercel có rác/đầu ra cũ từ trước -> phải bị xoá, PASS
# Cách dùng: bash 05_ci_clean_dir_equivalence.sh <git clone repo> <thư mục làm việc>
set -u
REPO="$(cd "$1" && pwd -P)"; WORK="$2"
M=609ed1bd7cdbea76842745985e34c13e91e050c4; H=a1aa7005d27dc617566f8e94eaf13b9c227bba7b
WF=.github/workflows/chinam-stage1-verification.yml
rm -rf "$WORK" && mkdir -p "$WORK"

extract_body() { # $1 = commit -> in ra thân 'run: |' của bước build sạch
  git -C "$REPO" show "$1:$WF" | python3 -c '
import sys, yaml
wf = yaml.safe_load(sys.stdin)
for s in wf["jobs"]["verify"]["steps"]:
    if s.get("name","").startswith("Build kiểu Vercel"):
        sys.stdout.write(s["run"]); break
'
}
extract_body $M >"$WORK/step_M.sh"; extract_body $H >"$WORK/step_H.sh"
echo "### diff thân bước M -> H"; diff -u "$WORK/step_M.sh" "$WORK/step_H.sh"

mk_src() { # $1 = tên, $2 = có thêm .vercel/output bị track không (yes/no)
  local d="$WORK/src_$1"
  git -C "$REPO" worktree add --detach "$d" $H >/dev/null 2>&1
  if [ "$2" = yes ]; then
    mkdir -p "$d/.vercel/output/static" && echo "<html>legacy</html>" >"$d/.vercel/output/static/index.html"
    git -C "$d" add -f .vercel/output >/dev/null && git -C "$d" -c user.name=r2 -c user.email=r2@invalid commit -qm "r2: simulate tracked stale output"
  fi
  echo "$d"
}

run_step() { # $1 = nhãn, $2 = tệp thân bước, $3 = src, $4 = RUNNER_TEMP
  local out rc
  out="$(cd "$3" && CI=1 RUNNER_TEMP="$4" bash -e "$2" 2>&1)"; rc=$?
  echo "=== $1 EXIT=$rc"; printf '%s\n' "$out" | grep -E 'FAIL|CLEAN_VERCEL_BUILD|GROK_EXTENSION_IN_STATIC|CHINAM_FOUNDATION_V2' | head -5
}

S1=$(mk_src t1 no); S2=$(mk_src t2 yes)
mkdir -p "$WORK/rt_M1" "$WORK/rt_H1" "$WORK/rt_M2" "$WORK/rt_H2" "$WORK/rt_H3"
# Bản M dùng mktemp: đặt TMPDIR để mktemp tạo trong thư mục làm việc
TMPDIR="$WORK/rt_M1" run_step "T1/M (mktemp)"        "$WORK/step_M.sh" "$S1" "$WORK/rt_M1"
run_step                      "T1/H (RUNNER_TEMP)"   "$WORK/step_H.sh" "$S1" "$WORK/rt_H1"
TMPDIR="$WORK/rt_M2" run_step "T2/M stale tracked"   "$WORK/step_M.sh" "$S2" "$WORK/rt_M2"
run_step                      "T2/H stale tracked"   "$WORK/step_H.sh" "$S2" "$WORK/rt_H2"
mkdir -p "$WORK/rt_H3/chinam-clean-vercel/.vercel/output/functions/__server.func"
echo 'export default { fetch: () => new Response("<html>STALE-R2</html>", { status: 200 }) };' \
  >"$WORK/rt_H3/chinam-clean-vercel/.vercel/output/functions/__server.func/index.mjs"
touch "$WORK/rt_H3/chinam-clean-vercel/R2_JUNK_MARKER"
run_step                      "T3/H pre-existing junk in RUNNER_TEMP" "$WORK/step_H.sh" "$S1" "$WORK/rt_H3"
echo "R2_JUNK_MARKER còn tồn tại sau T3? $(test -e "$WORK/rt_H3/chinam-clean-vercel/R2_JUNK_MARKER" && echo YES || echo NO)"
echo "STALE-R2 còn trong hàm máy chủ sau T3? $(grep -q STALE-R2 "$WORK/rt_H3/chinam-clean-vercel/.vercel/output/functions/__server.func/index.mjs" && echo YES || echo NO)"
echo "Thư mục mktemp (tmp.*) của M còn lại sau T1 (trap đã xoá => 0): $(find "$WORK/rt_M1" -maxdepth 1 -name 'tmp.*' | wc -l)  [node-compile-cache của Node không tính]"
echo "Thư mục của H còn lại cho bước sau (T1)? $(test -f "$WORK/rt_H1/chinam-clean-vercel/.vercel/output/functions/__server.func/index.mjs" && echo YES || echo NO)"
git -C "$REPO" worktree remove --force "$S1" >/dev/null 2>&1; git -C "$REPO" worktree remove --force "$S2" >/dev/null 2>&1
