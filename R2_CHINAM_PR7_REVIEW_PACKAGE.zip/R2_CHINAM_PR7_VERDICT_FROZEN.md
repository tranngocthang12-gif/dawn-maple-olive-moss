# R2 ĐỘC LẬP — CHẤM PR #7 CHỈNAM (`chinam/rel-02-settings-guard`) — BẢN ĐÓNG BĂNG

**MIỄN TRỪ W-01.** Người thi công là Claude Code; R2 là Claude trong một phiên chat ẩn danh trên claude.ai. Owner miễn trừ luật "người chấm khác hãng người viết" vì phiên này không chung ngữ cảnh với người thi công và mọi bằng chứng dưới đây đều chạy lại được bằng `harness/` trong gói kèm theo. R2 không đọc log CI và không coi lời khai của người thi công (mô tả PR, thông điệp commit, sổ vận hành) là bằng chứng. R2 không sửa mã.

| Mục | Giá trị |
| --- | --- |
| Đầu PR được chấm (H) | `a1aa7005d27dc617566f8e94eaf13b9c227bba7b` — nhánh `chinam/rel-02-settings-guard`, trùng `refs/pull/7/head` |
| Gốc của PR (M, `main`) | `609ed1bd7cdbea76842745985e34c13e91e050c4` |
| SHA-256 ZIP H `H_pr7_a1aa700.zip` | `ba63a79a59eb59c82153e73b944b1386953370107bceb4e0dfcf6da6e10fa4f1` |
| SHA-256 ZIP M `M_main_609ed1b.zip` | `60695a096aadfa6dceda59b103570427b2ecdd5a69db3c74826a8eec04afd205` |
| Môi trường | Ubuntu 24.04.5 LTS, x86_64, 1 vCPU, ~4 GB RAM; Node v22.23.4 (cùng nhánh 22 với CI), npm 10.9.9, git 2.43.0; không có Chromium |
| Mạng | registry npm và github.com dùng được; api.github.com bị giới hạn lượt gọi; claude.ai, vercel.com, grok.com không phân giải được từ sandbox |
| Thời điểm chấm | 2026-11-11 (UTC) |

**Nhãn bằng chứng.** Mỗi khẳng định mang một trong ba nhãn:
- `SOURCE_EVIDENCE`: R2 tự chạy và ra kết quả; tệp kết quả trong gói được ghi kèm.
- `ANALYTICAL_CLAIM`: suy luận của R2 từ mã nguồn hoặc từ ngữ nghĩa đã biết của công cụ, không chạy trực tiếp.
- `CHƯA ĐỦ BẰNG CHỨNG`: R2 không kiểm được.

---

## 1. Xác minh đầu vào

- **ZIP khớp commit.** Archive comment của hai ZIP lần lượt là `609ed1bd…e050c4` và `a1aa7005…bba7b`; thư mục gốc là `dawn-maple-olive-moss-<SHA>/` với đúng SHA tương ứng. ZIP M có 171 mục, ZIP H có 174 mục. `SOURCE_EVIDENCE: results/00_environment.txt`
- **ZIP khớp repo công khai.** R2 clone repo công khai. `git archive <SHA> | tar -x` của cả hai commit **trùng toàn bộ nội dung** với ZIP tương ứng (`diff -r` rỗng). `SOURCE_EVIDENCE: results/00_environment.txt`
- **Quan hệ nhánh.** `origin/chinam/rel-02-settings-guard` và `refs/pull/7/head` đều bằng `a1aa700…`. `merge-base(M, H) = M`. H cách M đúng 3 commit. `SOURCE_EVIDENCE: results/diff/01_diff_scope.txt`

## 2. Việc 1 — Diff M → H

### 2.1 Danh sách tệp và việc được phép tương ứng

Tổng: 8 tệp, +317/−21 dòng, 0 tệp bị xóa. `SOURCE_EVIDENCE: results/diff/01_diff_scope.txt`

| Tệp | Loại | Commit | Thuộc việc được phép |
| --- | --- | --- | --- |
| `.github/workflows/chinam-stage1-verification.yml` | đổi (+4/−2 dòng mã, +1 dòng chú thích) | `2283b79` | (1) thêm bước CI; (4) đổi thư mục build sạch |
| `scripts/check-built-server-grok-extension.mjs` | thêm (84 dòng) | `2283b79` | (1) |
| `scripts/check-live-no-grok-extension.mjs` | thêm (72 dòng) | `a427f00` | (2) |
| `scripts/check-live-no-grok-extension.test.mjs` | thêm (115 dòng) | `a427f00` | (2) |
| `AGENTS.project.md` | đổi | `a1aa700` | (3) |
| `PROJECT_STATE_V1.md` | đổi | `a1aa700` | (3) |
| `TASK_QUEUE_V1.md` | đổi | `a1aa700` | (3) |
| `REVIEW_LOG.md` | đổi | `a1aa700` | (3) |

### 2.2 Vùng bảo vệ, thư viện và tính năng

- **0 tệp bị đổi** trong `scripts/grok-pwa-*`, `server/`, `public/__grok/`, `src/`, `package.json`, `package-lock.json`. Mã băm git của các mục sau giống hệt nhau giữa M và H: blob `package.json`, `package-lock.json`, `vercel.json`, `AGENTS.md`; tree `server`, `public/__grok`, `src`; blob 4 tệp `scripts/grok-pwa-*`. `SOURCE_EVIDENCE: results/diff/01_diff_scope.txt`
- **Không thêm thư viện.** Ba tệp mới chỉ import module `node:*`. Riêng tệp test đọc thêm hằng `GROK_EXTENSIONS_SCRIPT_SRC` từ `scripts/grok-pwa-shared.mjs` (chỉ đọc, không sửa). `SOURCE_EVIDENCE: results/H_pipeline/19_format_imports_workflow_flags.log`
- **Không đổi tính năng app**, vì `src/` không đổi. `SOURCE_EVIDENCE` (tree hash như trên).
- **Không thêm mã gỡ hay chặn script nền tảng.** Không có header CSP, không sửa `vercel.json`, không có mã strip. Hai script mới chỉ đọc HTML và báo kết quả. `ANALYTICAL_CLAIM`, dựa trên việc đọc toàn bộ diff (`results/diff/03_full_diff_M_to_H.patch`).

### 2.3 Thông điệp commit

| Commit | Tiêu đề |
| --- | --- |
| `2283b79` | `ci(REL-02): assert built server HTML has no grok extensions script with VITE_GROK_EXTENSIONS=0` |
| `a427f00` | `test(REL-02): add live deployment check for the grok extensions script` |
| `a1aa700` | `docs(ops): record owner decisions D-1..D-3, roles from order 4.1, REL-02` |

Nội dung thân của cả ba commit mô tả đúng các tệp mà commit đó đổi; không commit nào nói đã đóng REL-02. `SOURCE_EVIDENCE: results/diff/02_commit_messages_PR7.txt`. Phần siêu dữ liệu commit xem mục 7 và R2C7-03.

## 3. Việc 2 — Chạy trên H

Cách chạy: harness `01_pipeline_H.sh` trên một git worktree của H, đúng thứ tự và lệnh của workflow. Bước build sạch được chạy bằng chính thân bước CI tại H, chỉ thay `$RUNNER_TEMP` bằng thư mục cục bộ. `SOURCE_EVIDENCE: results/H_pipeline/*.log`. Đối chứng M: `results/M_baseline_pipeline/*.log`.

| Bước | Lệnh | H | M (đối chứng) |
| --- | --- | --- | --- |
| Cài | `npm ci --ignore-scripts --no-audit --no-fund` (cờ như CI) | EXIT=0, "added 428 packages" | EXIT=0 |
| Typecheck | `npm run typecheck` (`tsc --noEmit`) | EXIT=0, không có thông báo | EXIT=0 |
| Lint | `npm run lint` | EXIT=0, "✖ 1 problem (0 errors, 1 warning)" | giống hệt H |
| Test | `npm test` (3 lần chạy `node --test`) | EXIT=0 | EXIT=0 |
| Build smoke | `VITE_GROK_EXTENSIONS=0 … vite build` | EXIT=0 | EXIT=0 |
| Build đủ | `VITE_GROK_EXTENSIONS=0 npm run build` | EXIT=0 | EXIT=0 |
| Build sạch kiểu Vercel | thân bước CI tại H | EXIT=0 | EXIT=0 |
| Kiểm hàm máy chủ | `node scripts/check-built-server-grok-extension.mjs <…/.vercel/output>` | EXIT=0 | (M chưa có script này) |

Ghi chú cho các dòng trên:
- **Lint:** cảnh báo duy nhất nằm ở `src/components/ui.tsx:29:17` (`react-refresh/only-export-components`) và đã có sẵn trên M.
- **Build sạch kiểu Vercel:** in ra `CLEAN_VERCEL_BUILD: PASS`, `GROK_EXTENSION_IN_STATIC: ABSENT`, `CHINAM_FOUNDATION_V2_IN_OUTPUT: PRESENT`.

**Số liệu `npm test` (nguyên văn tổng kết node:test):**

| Lần chạy | H | M |
| --- | --- | --- |
| 1 (`scripts/**/*.test.mjs`) | `# tests 203` `# pass 203` `# fail 0` `# skipped 0` | `# tests 197` `# pass 197` |
| 2 (`src/lib/…`) | `# tests 59` `# pass 59` `# fail 0` | `# tests 59` `# pass 59` |
| 3 (`src/foundation/…`) | `# tests 103` `# pass 101` `# fail 0` `# skipped 2` | `# tests 103` `# pass 101` `# skipped 2` |

- Chênh lệch +6 ở lần chạy 1 đúng bằng 6 test `REL-02 live check: …` mới, tất cả `ok`.
- Hai test bị bỏ qua (`CI production smoke: vite build`, `R2-F-04-m: native Chromium…`) cần `CHINAM_REAL_BROWSER_TEST=1` và Chromium, sandbox không có. M bỏ qua đúng hai test này. PR không đụng chúng.
- `SOURCE_EVIDENCE: results/H_pipeline/13_test.log`, `results/M_baseline_pipeline/13_test.log`

**Script kiểm hàm máy chủ trên build sạch của H (nguyên văn):**
```
PASS: VITE_GROK_EXTENSIONS=0 -> status 200, html 4999 bytes, grok-app-builder/extensions.js ABSENT (expected ABSENT)
PASS: VITE_GROK_EXTENSIONS unset (control) -> status 200, html 5076 bytes, grok-app-builder/extensions.js PRESENT (expected PRESENT)
BUILT_SERVER_GROK_EXTENSION_CHECK: PASS
```
`SOURCE_EVIDENCE: results/H_pipeline/17_check_built_server.log`

**Đối chiếu một lời ghi trong sổ vận hành.** `PROJECT_STATE_V1.md` dòng 31 ghi rằng script này, chạy trên build sạch của `609ed1b`, cho "`=0` → ABSENT, unset → PRESENT". R2 chạy lại và ra cùng kết quả, cùng số byte 4999/5076. Thư mục build dùng cho phép thử này đã được kiểm khớp mã nguồn `609ed1b`: chỉ `package-lock.json` khác, và khác biệt đó do chính lệnh `npm install --omit=dev` trong bước build sạch viết lại cờ dev/optional, có ở cả M và H. `SOURCE_EVIDENCE: results/M_baseline_pipeline/18_H_script_on_M_output.log`

## 4. Việc 3 — Bước CI mới

### 4.1 Có phân biệt được hai trường hợp không

**Có.** Trên build thật:
- `VITE_GROK_EXTENSIONS=0` lúc chạy cho kết quả ABSENT (4999 byte).
- Không đặt biến lúc chạy cho kết quả PRESENT (5076 byte).

Cả hai đều trên cùng một bản build đã build với `=0`. Điều này cũng là bằng chứng rằng đặt biến lúc build là chưa đủ, phải đặt cả lúc chạy, đúng như sổ vận hành yêu cầu. `SOURCE_EVIDENCE: results/H_pipeline/17_check_built_server.log`

**Ca đối chứng có tác dụng thật.** Một hàm giả không bao giờ chèn script làm script đỏ ở ca đối chứng (ca H bên dưới). Một hàm giả luôn chèn script làm script đỏ ở ca `=0` (ca G). Nghĩa là phép kiểm không thể xanh một cách vô nghĩa. `SOURCE_EVIDENCE: results/ci_step/02_failclosed_built_server_check.log`

**Giá trị nào thực sự tắt được script.** Hàm máy chủ thật được gọi với 5 giá trị của biến:
- `"0"` và `" 0 "`: ABSENT.
- Không đặt, `"false"`, `""`: PRESENT.

Như vậy chỉ đúng giá trị `0` (sau khi bỏ khoảng trắng) mới tắt được script. Sổ vận hành ghi đúng giá trị `0`. `SOURCE_EVIDENCE: results/probe/03_probe_built_function_paths.log`

**Trang `/` có đại diện được cho các trang khác không.** Với từng giá trị của biến, `/`, `/?utm=1` và một trang 404 (`/khong-ton-tai-r2`) cho cùng kết quả. Trang hướng dẫn cài `/?install=1&platform=ios` không chứa script trong mọi trường hợp. Output tĩnh không có tệp HTML nào. Vậy kiểm `/` đại diện được cho các trang HTML do hàm máy chủ sinh ra. `SOURCE_EVIDENCE: results/probe/03_probe_built_function_paths.log`

### 4.2 Có fail-closed không

Script của H được chạy lên các thư mục `.vercel/output` giả. `SOURCE_EVIDENCE: results/ci_step/02_failclosed_built_server_check.log`

| Ca | Tình huống | Kết quả |
| --- | --- | --- |
| A, B, L | không có hàm máy chủ / thư mục hàm thiếu `index.mjs` / đường dẫn không tồn tại | `FAIL: missing built server function`, EXIT=1 |
| C | hàm ném lỗi khi import | EXIT=1 (`server function call failed (exit 1)`) |
| D | không có `default.fetch` | EXIT=1 (`exit 2: … no default export with .fetch`) |
| E | trả 500 | EXIT=1 |
| F | trả 200 với thân rỗng | EXIT=1 (có kiểm `length > 0`) |
| G | luôn chèn script | EXIT=1 (ca `=0` FAIL) |
| H | không bao giờ chèn | EXIT=1 (ca đối chứng FAIL) |
| J | có rác trên stdout sau kết quả | EXIT=1 (lỗi `JSON.parse`) |
| K | hàm treo vĩnh viễn | EXIT=1 sau 60 s (`timeout: 60_000`) |
| I | hàm giả tôn trọng biến | EXIT=0 (đúng) |
| M | build sạch thật | EXIT=0 (đúng) |
| N | gọi script bằng đường dẫn tuyệt đối đi qua symlink, trên thư mục **rỗng** | **EXIT=0, không in gì** → xem R2C7-02 |

**Khi bước build trước lỗi.** Workflow tại H không có `if:` hay `continue-on-error` ở bất kỳ bước nào (`SOURCE_EVIDENCE: results/H_pipeline/19_format_imports_workflow_flags.log`). Theo ngữ nghĩa mặc định `if: success()` của GitHub Actions, khi bước build sạch đỏ thì bước mới bị bỏ qua và job vẫn đỏ (`ANALYTICAL_CLAIM`; R2 không chạy được Actions). Nếu build "xanh" mà không sinh ra hàm máy chủ, bước mới đỏ (ca A/B/L, `SOURCE_EVIDENCE`).

### 4.3 Đổi thư mục build có làm yếu phép kiểm cũ không

**Không.** Harness `05` trích thân bước "Build kiểu Vercel" của M và của H trực tiếp từ YAML bằng `git show`, rồi chạy dưới `bash -e`. `SOURCE_EVIDENCE: results/ci_step/05_ci_clean_dir_equivalence.log`

- **Phạm vi thay đổi:** chỉ 3 dòng tạo thư mục khác nhau (`mktemp -d` + `trap rm` được thay bằng `$RUNNER_TEMP/chinam-clean-vercel` + `rm -rf && mkdir -p`). Mọi phép kiểm sau đó giữ nguyên từng chữ.
- **T1 (mã nguồn H bình thường):** M và H cùng EXIT=0 và in cùng 4 dòng `CLEAN_VERCEL_BUILD`/`GROK_EXTENSION_IN_STATIC`/`CHINAM_FOUNDATION_V2_IN_OUTPUT`.
- **T2 (commit có `.vercel/output` bị track):** M và H cùng EXIT=1 với `FAIL: stale prebuilt output in clean archive`.
- **T3 (H, `$RUNNER_TEMP/chinam-clean-vercel` có sẵn rác và một hàm máy chủ "STALE" cũ):** rác bị xóa, hàm cũ bị thay, EXIT=0.
- **Thư mục build được giữ lại:** bản H để lại thư mục build cho bước sau (mục đích của việc 4); bản M xóa nó bằng `trap`.

Thư mục giữ lại không ảnh hưởng bước F-04 phía sau, vì F-04 chạy trong workspace chứ không trong thư mục này (`ANALYTICAL_CLAIM`, đọc workflow).

### 4.4 Giới hạn

R2 không chạy được GitHub Actions thật và không đọc log CI (theo lệnh). Phần "bước bị bỏ qua khi bước trước đỏ" là `ANALYTICAL_CLAIM`. Bước F-04 (Chromium) không chạy được trong sandbox và không bị PR đổi.

## 5. Việc 4 — Script kiểm bản chạy thật `scripts/check-live-no-grok-extension.mjs`

Cách thử: harness `04` dựng hai máy chủ giả cục bộ (hai origin khác nhau) và chạy **đúng lệnh CLI** mà Owner sẽ chạy (`node scripts/check-live-no-grok-extension.mjs <url>`) cho 43 ca. Mỗi ca ghi mã thoát và thời gian. "XANH SAI" nghĩa là script thoát 0 trong khi kết quả an toàn phải là đỏ. `SOURCE_EVIDENCE: results/live_check/04_attack_live_check.log`

### 5.1 Kết quả theo nhóm

| Nhóm | Ca | Kết quả |
| --- | --- | --- |
| Chèn script nguyên văn (12) | query string `?v=123&t=9`; `<SCRIPT DEFER SRC=…>`; host viết hoa `GROK.COM`; đổi thứ tự thuộc tính, nháy đơn; `type="module"`; `<link rel="preload">`; `import("…")` inline; URL không giao thức `//grok.com/…`; script cuối `<body>`; HTML 5 MB với script ở cuối; chuỗi bị cắt giữa 3 chunk; nén gzip | **12/12 ĐỎ** (EXIT=1) |
| Chuyển hướng (5) | sang trang có script, cùng origin và khác origin; vòng lặp; sang `file:` | **4/5 ĐỎ** |
| | sang origin khác, trang HTML sạch nhưng **không phải app** | **XANH SAI** |
| 2xx nhưng không phải trang app (6) | 200 JSON; 200 text/plain; 200 thân rỗng; 204; 200 PNG; 200 HTML không phải CHỈNAM | **6/6 XANH SAI** (ví dụ `PASS: … -> HTML (0 bytes) has no …`) |
| Treo (3) | không trả header; trả header rồi treo; nhỏ giọt một byte mỗi 0,5 s mãi mãi | **3/3 ĐỎ** sau 20,04–20,06 s (`The operation was aborted due to timeout`) |
| Đối số (10) | thiếu đối số; chuỗi rỗng | EXIT=2 (usage) |
| | chuỗi rác; `ftp:`; `file:`; `javascript:`; URL có `user:pass@`; host không phân giải được | EXIT=1 |
| | URL chỉ có host, không có đường dẫn | kiểm `/` của host; máy chủ giả trả 404 nên ĐỎ |
| | thêm đối số thứ hai | bị **bỏ qua im lặng**, chỉ URL đầu được kiểm |
| Đối chứng (3) | trang app sạch; trang 5 MB sạch | XANH (đúng) |
| | 500 | ĐỎ (đúng) |
| Dạng mã hóa (4) | đường dẫn viết hoa `/GROK-APP-BUILDER/EXTENSIONS.JS`; `&#x2F;` thay `/`; URL ghép bằng JS; HTML UTF-16 có BOM | 4/4 XANH, xem 5.3 |

Tổng: `TOTAL=43 FALSE_GREEN=11`, gồm 6 ca 2xx-không-phải-app, 1 ca chuyển hướng khác origin và 4 ca mã hóa.

### 5.2 Thời hạn chờ

Có thời hạn chờ: `AbortSignal.timeout(20_000)` phủ cả giai đoạn chờ header lẫn đọc thân. Ba kiểu treo đều đỏ trong khoảng 20 s (`SOURCE_EVIDENCE`, bảng trên).

Tuy vậy, **test đơn vị không phủ thời hạn chờ**: bỏ dòng `signal: AbortSignal.timeout(timeoutMs)` thì 6/6 test vẫn xanh. Test cũng không phủ chuyển hướng: đổi `redirect: "follow"` thành `"manual"` vẫn 6/6 xanh. Test có bắt được việc bỏ kiểm mã trạng thái và bỏ kiểm chuỗi script. `SOURCE_EVIDENCE: results/live_check/06_mutation_live_check_tests.log`

| Đột biến | Kết quả |
| --- | --- |
| M0 no-op (đối chứng) | xanh (đúng) |
| M1 bỏ timeout | **SURVIVED** |
| M2 bỏ kiểm 2xx | CAUGHT |
| M3 bỏ kiểm chuỗi script | CAUGHT |
| M4 không theo chuyển hướng | **SURVIVED** |
| M5 so chuỗi không phân biệt hoa thường | survived, đột biến tương đương nên không tính |
| M6 bỏ kiểm giao thức | survived, đột biến tương đương nên không tính |

### 5.3 Dạng mã hóa: không phải finding

Bốn ca mã hóa xanh vì script so một chuỗi con nguyên văn. Tuy nhiên bộ chèn của nền tảng chỉ sinh **một dạng duy nhất**: `<script src="https://grok.com/grok-app-builder/extensions.js" … defer></script>`, lấy từ hằng `GROK_EXTENSIONS_SCRIPT_SRC` trong `scripts/grok-pwa-shared.mjs` (`ANALYTICAL_CLAIM`, đọc mã nền tảng). Test `needle matches the platform script URL` buộc chuỗi tìm khớp hằng đó, và ca đối chứng trong CI chứng minh chuỗi tìm bắt được đầu ra thật của bộ chèn (`SOURCE_EVIDENCE`).

R2 ghi bốn ca này là giới hạn đã biết, không phải finding, và không yêu cầu sửa.

### 5.4 Trả lời câu hỏi "có đường nào cho XANH sai không"

**Có**, và là đường thực tế: mọi phản hồi 2xx sau khi theo chuyển hướng mà không chứa chuỗi script đều cho `PASS` và thoát 0. Điều đó đúng bất kể phản hồi là trang gì: JSON, văn bản, rỗng, 204, ảnh, một trang HTML khác, hay trang của một origin khác mà URL chuyển hướng tới. `SOURCE_EVIDENCE: results/live_check/04_attack_live_check.log`

Script làm đúng những gì phần chú thích đầu tệp mô tả. Vấn đề nằm ở cách kết quả `PASS` được dùng: sổ vận hành dùng nó làm điều kiện đóng cả REL-01 lẫn REL-02 (`PROJECT_STATE_V1.md` dòng 26, 30, 31; `TASK_QUEUE_V1.md` dòng 11). Hai chỗ trong sổ nói như sau:
- REL-01: "Closes when the deployed site built from `main` is checked with the live check script".
- TASK_QUEUE bước 5: "on PASS close REL-01 and REL-02".

Một `PASS` trên trang không phải CHỈNAM vì thế sẽ dẫn tới đóng sai cả hai mục, trong khi định nghĩa "Xong" của Owner là app chạy thật từ `main`. `ANALYTICAL_CLAIM` → **R2C7-01**.

**Dấu hiệu nhận biết app có sẵn.** Hàm máy chủ thật render `/` với `<title>CHỈNAM — Bàn vận hành</title>`, `content-type: text/html; charset=utf-8`, khoảng 5 KB. Tức là đã có sẵn dấu hiệu để phân biệt trang app với trang khác. `SOURCE_EVIDENCE: results/probe/03_probe_built_function_paths.log`

**Ngoài ra:** gọi script bằng đường dẫn tuyệt đối đi qua symlink thì `main()` không chạy và script thoát 0, không in gì, kể cả khi trang **có** script. Gọi bằng đường dẫn tương đối từ gốc repo, như sổ vận hành hướng dẫn, thì vẫn đúng. `SOURCE_EVIDENCE: results/live_check/05_symlink_guard.log` → **R2C7-02**.

**Hành vi của Vercel với Preview.** R2 không biết Vercel trả gì cho Preview bật Deployment Protection (4xx hay chuyển hướng sang trang đăng nhập 200), vì sandbox không tới được vercel.com. `CHƯA ĐỦ BẰNG CHỨNG`. Nếu Vercel trả 4xx, script đỏ, tức an toàn nhưng không kiểm được. Nếu Vercel chuyển hướng sang một trang 200, đó rơi đúng vào lỗ R2C7-01.

## 6. Việc 5 — Sổ vận hành

| Yêu cầu của Owner | Trạng thái tại H | Nhãn |
| --- | --- | --- |
| D-1 Vercel build từ `main`; D-2 dữ liệu ở trình duyệt; D-3 không mở Giai đoạn 4; "Xong" = app chạy thật từ `main`, REL-01 và REL-02 đóng | Có đủ ở `PROJECT_STATE_V1.md` (mục "Owner decisions", dòng 21) và `TASK_QUEUE_V1.md`; "Stage 4: LOCKED" giữ nguyên | `SOURCE_EVIDENCE` (đọc tệp) |
| REL-02 ở trạng thái "giảm thiểu bằng cài đặt — chờ kiểm bản chạy thật", không bị ghi là đã đóng | Dòng 31: `status: "GIẢM THIỂU BẰNG CÀI ĐẶT — chờ kiểm bản chạy thật"`; không chỗ nào ghi REL-02 đã đóng; TASK_QUEUE để việc đóng ở bước 5 (PENDING) | `SOURCE_EVIDENCE` |
| Tôn trọng `AGENTS.md`; chỉ tắt bằng cài đặt; không sửa tệp nền tảng | `AGENTS.project.md` dòng 15: "Script nền tảng chỉ được tắt bằng cài đặt … Không sửa scripts/grok-pwa-*, server/, public/__grok/"; TASK_QUEUE liệt kê việc sửa tệp nền tảng vào mục cấm | `SOURCE_EVIDENCE` |
| Mục Triển khai: **bắt buộc** đặt `VITE_GROK_EXTENSIONS=0` cho Production **và** Preview | Dòng 25: "**REQUIRED:** set `VITE_GROK_EXTENSIONS=0` for **Production** and **Preview** in the Vercel project configuration (runtime environment)" | `SOURCE_EVIDENCE` |
| Chạy script kiểm sau **mỗi** lần triển khai | Dòng 26: "After **every** deployment run `node scripts/check-live-no-grok-extension.mjs <deployed URL>`; it must PASS (exit 0)" | `SOURCE_EVIDENCE` |
| Lệnh build/cài khớp `vercel.json` | Dòng 24 khớp `vercel.json` (không đổi) | `SOURCE_EVIDENCE` |
| "`vercel.json` covers the build only; the built server function reads the variable at runtime" | Nửa sau đúng: build với `=0` mà chạy không đặt biến thì script vẫn bị chèn (mục 4.1). Nửa đầu nói về khóa `env` trong `vercel.json` có áp dụng lúc chạy trên Vercel hay không; R2 không kiểm được. Câu này dẫn tới yêu cầu chặt hơn nên vô hại | nửa sau `SOURCE_EVIDENCE`; nửa đầu `CHƯA ĐỦ BẰNG CHỨNG` |
| SHA PR #6 trong sổ | Head `16303010…` bằng `refs/pull/6/head` và là cha thứ hai của merge `609ed1b` | `SOURCE_EVIDENCE: results/github_api/pr6_sha_check.txt` |

**Những điểm R2 không kiểm được** (không phải finding, Owner tự đối chiếu):
- Nội dung bình luận R2 của PR #6 (`issuecomment-6759515840`), gồm lời ghi "Raised REL-02 (MEDIUM, pre-existing, not blocking)". API GitHub trả "rate limit exceeded". `CHƯA ĐỦ BẰNG CHỨNG: results/github_api/api_attempt_note.txt`
- Vai "Chief Engineer", miễn trừ W-02, và câu "**Hard rules (unchanged)** … no deleting, no merging into `main`, no signing, no touching secret keys". Các nội dung này không có trong sổ vận hành ở M và cũng không có trong lệnh R2 nhận, nên chữ "unchanged" không truy được nguồn trong repo. `CHƯA ĐỦ BẰNG CHỨNG`
- `REVIEW_LOG.md` tự mô tả là chỉ mục các kết luận "independent Claude R2". Dòng PR #6 ghi rõ người chấm là Chief Engineer theo W-02 nhưng nhãn liên kết vẫn là "Owner-forwarded R2". Đây là cách dùng chữ, không sai dữ kiện. `ANALYTICAL_CLAIM`

Kết luận việc 5: các yêu cầu bắt buộc của Owner về REL-02, Deployment và D-1..D-3 **đều có và đúng**. Lỗ duy nhất liên quan nằm ở chỗ sổ dùng `PASS` của script live làm điều kiện đóng (R2C7-01).

## 7. Việc 6 — Repo công khai

Quét các dòng **thêm** trong diff và toàn bộ thông điệp cùng tiêu đề tác giả của 3 commit. `SOURCE_EVIDENCE: results/diff/04_secret_scan.txt`

- **Địa chỉ thư:** 0 trong diff. Trong siêu dữ liệu commit có `noreply@anthropic.com` ở trường Author/Committer (6 lần); đây là địa chỉ no-reply chung của nhà cung cấp, không phải địa chỉ cá nhân.
- **Mật khẩu, khóa, token:** 0. Các mẫu `ghp_`/`github_pat_`/`sk-`/`AKIA`/`AIza`/JWT đều không có. Từ "secret keys" chỉ xuất hiện trong câu quy tắc "no touching secret keys".
- **URL:** chỉ có liên kết vào chính repo này, `https://grok.com/grok-app-builder/extensions.js`, địa chỉ cục bộ trong test, và **3 lần** trailer `Claude-Session: https://claude.ai/code/session_…` trong thông điệp commit → R2C7-03.
- **Repo khác:** không có URL `github.com/<owner>/<repo>` nào khác repo này.
- **Tên dự án khác:** tên "TRUNG TÂM TÀI CHÍNH" xuất hiện ở 3 tệp với cùng số dòng như trên M. Đó là lời ghi quyết định "không liên quan" đã có sẵn, không kèm đường dẫn hay chi tiết nào về repo đó. `ANALYTICAL_CLAIM`

---

## 8. Findings

### R2C7-01 — MEDIUM (chặn) — Script kiểm bản chạy thật cho PASS trên phản hồi không phải trang CHỈNAM

**Vị trí:**
- `scripts/check-live-no-grok-extension.mjs` dòng 34–39 (`redirect: "follow"`, theo sang bất kỳ origin nào), dòng 44–58 (mọi 2xx không chứa chuỗi script đều thành `ok: true`).
- Nơi `PASS` được dùng làm điều kiện đóng: `PROJECT_STATE_V1.md` dòng 26, 30, 31; `TASK_QUEUE_V1.md` dòng 11.

**Mô tả.** Script không kiểm rằng thứ nó đọc là trang HTML của CHỈNAM. Các trường hợp sau đều thoát 0 với dòng `PASS`:
- 200 JSON, 200 text, 200 thân rỗng, 204, 200 ảnh;
- 200 HTML của một trang khác;
- chuyển hướng sang origin khác có trang sạch.

Sổ vận hành dùng chính mã thoát 0 này làm điều kiện đóng REL-02 ("bản chạy thật được kiểm sạch") và REL-01 ("app chạy thật từ `main`"). Vì vậy một URL sai, một trang giữ chỗ, hay một chuyển hướng khỏi app đều có thể dẫn tới đóng sai cả hai mục. Phép kiểm "vắng mặt script" chỉ có nghĩa khi đã khẳng định được trang đang đọc đúng là app.

Ngoài ra, test đơn vị không phủ thời hạn chờ và chuyển hướng (đột biến M1, M4 sống sót).

**Tái hiện.** `node harness/04_attack_live_check.mjs <checkout H>` → 7 dòng `!! XANH SAI` thuộc nhóm `2xx non-app` và `redirect`. `bash harness/06_mutation_live_check_tests.sh <checkout H> /tmp/r2_mut` → M1 và M4 `SURVIVED`. Kết quả: `results/live_check/04_attack_live_check.log`, `results/live_check/06_mutation_live_check_tests.log`.

**Điều kiện đóng** (nằm trong việc được phép số (2), không thêm thư viện, không đụng tệp nền tảng):
1. Script thoát khác 0 khi phản hồi cuối cùng thuộc một trong các trường hợp: `content-type` không phải `text/html`; thân rỗng (kể cả 204); HTML không có một dấu hiệu dương tính của CHỈNAM do người thi công chọn (R2 đo được `/` của hàm máy chủ có `<title>CHỈNAM — Bàn vận hành</title>`); hoặc chuyển hướng kết thúc ở origin khác origin của URL đầu vào.
2. Script in ra URL cuối cùng đã kiểm.
3. Có test đơn vị với máy chủ giả cho từng trường hợp ở điểm 1, cho một ca chuyển hướng, và cho một ca treo dùng `timeoutMs` nhỏ.
4. R2 chạy lại `harness/04`: `FALSE_GREEN` chỉ còn 4 ca thuộc nhóm `encoded (not emitted by platform)`, 0 ca thuộc nhóm `2xx non-app` và `redirect`. R2 chạy lại `harness/06`: M1–M4 đều `CAUGHT`.

### R2C7-02 — LOW (không chặn) — Guard `import.meta.url` cho thoát 0 mà không kiểm gì khi gọi qua symlink

**Vị trí:** `scripts/check-live-no-grok-extension.mjs` dòng 72; `scripts/check-built-server-grok-extension.mjs` dòng 84.

**Mô tả.** Node lấy `import.meta.url` của tệp chính theo realpath, còn `process.argv[1]` chỉ được resolve mà không realpath. Gọi script bằng đường dẫn tuyệt đối đi qua symlink (ví dụ `/tmp/…` trên macOS, vốn là symlink) thì `main()` không chạy và tiến trình thoát 0, không in gì:
- Script live: thoát 0 ngay cả với trang **có** script.
- Script CI: thoát 0 với thư mục output **rỗng**.

Gọi bằng đường dẫn tương đối từ gốc repo (cách sổ vận hành ghi) hoặc thêm `--preserve-symlinks-main` thì đúng (`SOURCE_EVIDENCE`). Mẫu guard này đã có sẵn ở 3 script cũ của repo (`brand-check.mjs`, `preview.mjs`, `write-atomic.mjs`). Đường dẫn workspace của runner GitHub thường không qua symlink nên bước CI ít khả năng bị ảnh hưởng (`ANALYTICAL_CLAIM`). Trên Windows, khác biệt chữ hoa/thường của ổ đĩa có thể gây hiện tượng tương tự (`CHƯA ĐỦ BẰNG CHỨNG`, R2 không thử được).

**Tái hiện.** `bash harness/07_symlink_guard_live.sh <checkout H> /tmp/r2_sym2` → ca thứ 2 cho `[output 0 byte]`, `EXIT=0`. `bash harness/02_failclosed_built_server_check.sh …` → ca N cho `EXIT=0`. Kết quả: `results/live_check/05_symlink_guard.log`, `results/ci_step/02_failclosed_built_server_check.log`.

**Điều kiện đóng** (một trong hai):
- (a) Hai script mới không thể thoát 0 mà chưa chạy phép kiểm (ví dụ so khớp theo realpath), có test gọi qua symlink.
- (b) Owner chấp nhận rủi ro và sổ vận hành ghi rằng phải chạy từ gốc repo bằng đường dẫn tương đối, và chỉ coi là đạt khi có dòng bắt đầu bằng `PASS:`.

### R2C7-03 — LOW (không chặn) — Thông điệp commit chứa liên kết phiên claude.ai

**Vị trí:** thân thông điệp cả 3 commit `2283b79`, `a427f00`, `a1aa700` (trailer `Claude-Session: https://claude.ai/code/session_…`). Trường Author/Committer là `noreply@anthropic.com`.

**Mô tả.** Liên kết không phải mật khẩu, khóa hay token (`ANALYTICAL_CLAIM`). Tuy vậy nó trỏ tới phiên làm việc của người thi công. R2 không xác minh được trang đó có xem được công khai hay không, vì claude.ai không tới được từ sandbox (`CHƯA ĐỦ BẰNG CHỨNG`). Nếu xem được, phiên đó có thể lộ ngữ cảnh làm việc nằm ngoài repo. Địa chỉ `noreply` là địa chỉ chung bắt buộc phải có trong trường tác giả của git, không phải địa chỉ thư cá nhân; R2 ghi lại để Owner biết, không yêu cầu sửa.

**Tái hiện.** `bash harness/00_diff_scope_and_secret_scan.sh <repo> results/diff` → `results/diff/04_secret_scan.txt`, mục URL: `3 https://claude.ai/code/session_…`.

**Điều kiện đóng.** Owner xác nhận liên kết phiên không xem được công khai, hoặc chấp nhận để nguyên. Không yêu cầu viết lại lịch sử.

## 9. Những gì R2 không kiểm được

- GitHub Actions thật, gồm bước F-04 (Chromium) và ngữ nghĩa bỏ qua bước. Phần này là `ANALYTICAL_CLAIM`.
- Hành vi của Vercel thật: biến môi trường lúc chạy, khóa `env` trong `vercel.json`, Deployment Protection. Phần này `CHƯA ĐỦ BẰNG CHỨNG`, và đó chính là lý do REL-02 chỉ được đóng sau khi kiểm bản chạy thật.
- Nội dung bình luận PR #6 và nguồn gốc các mục vai trò, W-02 (mục 6).

## 10. Gói bằng chứng

`R2_CHINAM_PR7_REVIEW_PACKAGE.zip` gồm:
- `R2_CHINAM_PR7_VERDICT_FROZEN.md` (tệp này) và `R2_CHINAM_PR7_VERDICT_FROZEN.sha256`;
- `SHA256SUMS.txt`, ghi SHA-256 của mọi tệp trong gói trừ chính nó;
- `harness/`: 9 tệp chạy được, kèm `README.md` hướng dẫn tái hiện từ repo công khai;
- `results/`: log nguyên văn của mọi phép chạy kể trên.

---

## KẾT LUẬN: CHANGES REQUIRED

PR #7 làm đúng phạm vi được phép:
- 0 tệp nền tảng, 0 tệp `src/`, `package.json` và `package-lock.json` không đổi, không thêm thư viện.
- Pipeline trên H xanh hoàn toàn.
- Bước CI mới phân biệt thật được hai trường hợp, có đối chứng, fail-closed, và không làm yếu phép kiểm cũ.
- Sổ vận hành ghi đúng các quyết định D-1..D-3, ghi đúng REL-02 là "giảm thiểu bằng cài đặt — chờ kiểm bản chạy thật", và có yêu cầu bắt buộc đặt `VITE_GROK_EXTENSIONS=0` cho Production và Preview cùng việc chạy script kiểm sau mỗi lần triển khai.

Còn một finding chặn:

| Finding | Mức | Chặn | Tóm tắt | Điều kiện đóng |
| --- | --- | --- | --- | --- |
| **R2C7-01** | MEDIUM | **Có** | Script kiểm bản chạy thật thoát 0 trên phản hồi 2xx không phải trang CHỈNAM và trên chuyển hướng sang origin khác, trong khi mã thoát đó là điều kiện đóng REL-01 và REL-02 | Mục 8, điểm 1–4 |
| R2C7-02 | LOW | Không | Guard `import.meta.url` cho thoát 0 mà không kiểm gì khi gọi qua symlink | Mục 8, (a) hoặc (b) |
| R2C7-03 | LOW | Không | Thông điệp commit có liên kết phiên claude.ai | Owner xác nhận hoặc chấp nhận |

Sau khi R2C7-01 được sửa trong phạm vi việc (2), R2 cần chấm lại SHA mới bằng `harness/04` và `harness/06`. Owner giữ quyền gộp.
