# R2 ĐỘC LẬP — CHẤM LẠI PR #7 CHỈNAM, VÒNG 2 (`chinam/rel-02-settings-guard`) — BẢN ĐÓNG BĂNG

**MIỄN TRỪ W-01.** Người thi công là Claude Code; R2 là Claude trong một phiên chat ẩn danh trên claude.ai. Owner miễn trừ luật "người chấm khác hãng người viết" vì hai bên không chung ngữ cảnh, và mọi bằng chứng dưới đây đều chạy lại được bằng `harness/` trong gói kèm theo. R2 không đọc log CI. R2 không coi lời khai của người thi công (mô tả PR, thông điệp commit, sổ vận hành) là bằng chứng. R2 không sửa mã.

| Mục | Giá trị |
| --- | --- |
| **SHA được chấm (H2)** | `a867864073ca2fa11b725e53e088506da1584417`, trùng `refs/pull/7/head` và `origin/chinam/rel-02-settings-guard` lúc chấm |
| Đầu PR lúc vòng 1 (H1) | `a1aa7005d27dc617566f8e94eaf13b9c227bba7b` |
| Gốc PR (M, `main`) | `609ed1bd7cdbea76842745985e34c13e91e050c4` |
| SHA-256 ZIP P1 `R2_CHINAM_PR7_REVIEW_PACKAGE.zip` | `7139800520c859db30e0ccf98d883d4542b3380c9c04f1e7eb5d119ae8c38a9e` |
| SHA-256 ZIP H1 `H_pr7_a1aa700.zip` | `ba63a79a59eb59c82153e73b944b1386953370107bceb4e0dfcf6da6e10fa4f1` |
| SHA-256 ZIP H2 `H2_pr7_a867864.zip` | `36ee5e6ff6665313915d924cb1684e972b5a35b04b9b72721f313ba4f95beae3` |
| SHA-256 báo cáo vòng 1 | `060a84dd4bf71e9734bc12b065b64a18915ef35fe7d6e164c0b2576d0138e32e` |
| Môi trường | Ubuntu 24.04.5 LTS, x86_64, 1 vCPU, ~4 GB RAM; Node v22.23.4 (cùng nhánh 22 với CI), npm 10.9.9, git 2.43.0, python3 3.12.3, openssl 3.0.13; không có Chromium |
| Mạng | registry npm, github.com, codeload.github.com dùng được; api.github.com trả 403 vì giới hạn lượt gọi; vercel.com và claude.ai không tới được |
| Thời điểm chấm | 2026-11-11 (UTC) |

**Nhãn bằng chứng.** Mỗi khẳng định mang một trong ba nhãn:
- `SOURCE_EVIDENCE`: R2 tự chạy và ra kết quả; tệp kết quả trong gói được ghi kèm.
- `ANALYTICAL_CLAIM`: suy luận của R2 từ mã nguồn hoặc từ ngữ nghĩa đã biết của công cụ, không chạy trực tiếp.
- `CHƯA ĐỦ BẰNG CHỨNG`: R2 không kiểm được.

---

## 1. Xác minh đầu vào

- **ZIP khớp commit.**
  - Archive comment của H1 và H2 lần lượt là `a1aa7005…bba7b` và `a8678640…84417`.
  - Thư mục gốc là `dawn-maple-olive-moss-<SHA>/` với đúng SHA tương ứng.
  - H1 có 174 mục, H2 có 177 mục.
  - `SOURCE_EVIDENCE: results/00_environment.txt`
- **ZIP khớp repo công khai.** R2 clone repo công khai. `git archive <SHA> | tar -x` của cả hai commit **trùng toàn bộ** nội dung ZIP tương ứng (`diff -r` rỗng). Worktree H2 dùng để chạy cũng trùng ZIP H2. `SOURCE_EVIDENCE: results/00_environment.txt`
- **Quan hệ nhánh.** H1 là tổ tiên của H2, cách đúng 4 commit tuyến tính: `d336dfe` → `c5ede7a` → `372d47f` → `a867864`. `merge-base(M, H2) = M`. `SOURCE_EVIDENCE: results/diff/01_diff_scope_H1_H2.txt`
- **Gói vòng 1 toàn vẹn.**
  - `sha256sum -c SHA256SUMS.txt` của P1 cho 45/45 OK.
  - Báo cáo vòng 1 có SHA-256 `060a84dd…e32e`, khớp lệnh.
  - Bản ZIP P1 trên nhánh công khai `inbox/r2-pr7` (commit `9f32f13`) có cùng SHA-256 `71398005…a9e`.
  - Harness vòng 1 được chép sang `harness/v1/` **nguyên byte** (10 tệp, SHA-256 trùng).
  - `SOURCE_EVIDENCE: results/01_round1_package_integrity.txt`, `results/00_environment.txt`

## 2. Việc 1 — Diff H1 → H2

### 2.1 Danh sách tệp

Tổng: 9 tệp, +342/−75 dòng, 0 tệp bị xóa. `SOURCE_EVIDENCE: results/diff/01_diff_scope_H1_H2.txt`

| Tệp | Loại | +/− | Commit | Phục vụ |
| --- | --- | --- | --- | --- |
| `scripts/check-live-no-grok-extension.mjs` | đổi | +43/−16 | `d336dfe`, `c5ede7a` | R2C7-01 (kiểm origin, `content-type`, thân rỗng, dấu hiệu, in URL cuối); R2C7-02 (guard) |
| `scripts/check-live-no-grok-extension.test.mjs` | đổi | +176/−52 | `d336dfe`, `c5ede7a`, `372d47f` | R2C7-01 (test từng ca), R2C7-02 (test qua symlink) |
| `scripts/check-live-marker.test.mjs` | thêm | +15 | `372d47f` | R2C7-01 (ghim dấu hiệu vào title của `src/routes/index.tsx`, chỉ đọc) |
| `scripts/is-main-module.mjs` | thêm | +26 | `c5ede7a` | R2C7-02 (so realpath hai phía) |
| `scripts/check-built-server-grok-extension.mjs` | đổi | +3/−1 | `c5ede7a` | R2C7-02 (chỉ thay dòng guard và thêm import) |
| `scripts/check-built-server-grok-extension.test.mjs` | thêm | +69 | `c5ede7a` | R2C7-02 (test script CI qua symlink tệp và symlink thư mục) |
| `PROJECT_STATE_V1.md` | đổi | +3/−3 | `a867864` | sổ vận hành |
| `REVIEW_LOG.md` | đổi | +2/−1 | `a867864` | sổ vận hành |
| `TASK_QUEUE_V1.md` | đổi | +5/−2 | `a867864` | sổ vận hành |

Lời khai liệt kê hai tệp mới là `is-main-module.mjs` và `check-live-marker.test.mjs`. Diff thực tế có thêm tệp thứ ba, `scripts/check-built-server-grok-extension.test.mjs`. Tệp này là test symlink cho script CI, nằm trong commit `c5ede7a` mà thông điệp có nhắc ("Tests call both scripts through a file symlink and a directory symlink"). Nó thuộc đúng phạm vi R2C7-02. `SOURCE_EVIDENCE` (diff theo từng commit).

### 2.2 Vùng bảo vệ và phụ thuộc

- **0 tệp đổi** trong các vùng sau giữa H1 và H2, và cũng 0 tệp giữa M và H2: `scripts/grok-pwa-*`, `server/`, `public/__grok/`, `src/`, `package.json`, `package-lock.json`, `vercel.json`, `AGENTS.md`, `AGENTS.project.md`, `.github/`. `SOURCE_EVIDENCE: results/diff/01_diff_scope_H1_H2.txt`
- **Mã băm git giống hệt giữa H1 và H2:**
  - blob `package.json` (`0a8b417…`), `package-lock.json` (`9056f45…`), `vercel.json`, `AGENTS.md`, `AGENTS.project.md`, workflow `.github/workflows/chinam-stage1-verification.yml` (`4262ae5…`);
  - tree `server`, `public/__grok`, `src` (`0e466b6…`), `.github`;
  - blob 4 tệp `scripts/grok-pwa-*`.

  Với `server`, `public/__grok`, `src`, `package*.json` và `grok-pwa-*`, mã băm còn giống cả với M. `SOURCE_EVIDENCE`
- **Không thêm thư viện.** Các tệp đổi hoặc thêm chỉ import module `node:*` và các tệp cùng thư mục `scripts/`. Tệp test live vẫn đọc hằng `GROK_EXTENSIONS_SCRIPT_SRC` từ `scripts/grok-pwa-shared.mjs` như ở H1 (chỉ đọc). `SOURCE_EVIDENCE: results/diff/01_diff_scope_H1_H2.txt`, mục "Import"
- **Không đổi tính năng app** vì tree `src` không đổi. Không có mã gỡ hay chặn script nền tảng. Hai script chỉ đọc và báo kết quả. `ANALYTICAL_CLAIM`, đọc toàn bộ diff `results/diff/03_full_diff_H1_to_H2.patch`.

### 2.3 Thông điệp 4 commit mới

| Commit | Tiêu đề |
| --- | --- |
| `d336dfe` | `fix(R2C7-01): live check passes only on the CHỈNAM app page` |
| `c5ede7a` | `fix(R2C7-02): main-module guard compares realpaths, test via symlinks` |
| `372d47f` | `test(R2C7-01): keep live-check unit tests runnable from scripts/ alone` |
| `a867864` | `docs(ops): record PR #7 R2 round 1 and live-check pass criteria` |

Quét **thân** thông điệp của cả 4 commit (`SOURCE_EVIDENCE: results/diff/04_secret_scan_H1_H2.txt`, `02_commit_messages_H1_H2.txt`, `02b_commit_trailers_H1_H2.txt`):
- Liên kết phiên, `claude.ai`, `session_`, `Claude-Session`, `Co-Authored-By`, mọi `http(s)://`: **0**.
- Trailer git: **0**.
- Địa chỉ thư: **0**.
- Mẫu khóa (`ghp_`, `github_pat_`, `sk-`, `AKIA`, `AIza`, JWT): **0**.

Thân mỗi commit mô tả đúng các tệp mà commit đó đổi. Không commit nào nói REL-01 hay REL-02 đã đóng.

Trường Author/Committer của 4 commit là `Claude <noreply@anthropic.com>` (8 lần). Đây là siêu dữ liệu tác giả bắt buộc của git, không thuộc thân thông điệp, và là địa chỉ no-reply chung, giống vòng 1. R2 ghi lại để Owner biết, không coi là vi phạm quy định "thông điệp commit không có địa chỉ thư". `ANALYTICAL_CLAIM`

Trong các dòng thêm của diff: 0 địa chỉ thư, 0 mẫu khóa, 0 liên kết sang repo khác. URL chỉ gồm `https://grok.com/grok-app-builder/extensions.js`, liên kết vào chính repo này, `http://localhost:${…}` trong test và chỗ giữ chỗ `https://<deployment-host>/`. `SOURCE_EVIDENCE`

## 3. Việc 2 — Chạy trên H2

Cách chạy: harness vòng 1 `v1/01_pipeline_H.sh`, không sửa, trên git worktree của H2, đúng thứ tự và lệnh của workflow. Bước build sạch được chạy bằng chính thân bước CI; R2 dùng được thân bước của vòng 1 vì blob workflow ở H2 **trùng hệt** H1. `SOURCE_EVIDENCE: results/H2_pipeline/*.log`

| Bước | Lệnh | H2 |
| --- | --- | --- |
| Cài | `npm ci --ignore-scripts --no-audit --no-fund` | EXIT=0, "added 428 packages" |
| Typecheck | `npm run typecheck` | EXIT=0, không có thông báo |
| Lint | `npm run lint` | EXIT=0, "✖ 1 problem (0 errors, 1 warning)": cảnh báo cũ ở `src/components/ui.tsx:29:17`, có từ M |
| Test | `npm test` (3 lần chạy `node --test`) | EXIT=0 |
| Build smoke | `VITE_GROK_EXTENSIONS=0 … vite build` | EXIT=0 |
| Build đủ | `VITE_GROK_EXTENSIONS=0 npm run build` | EXIT=0 |
| Build sạch kiểu Vercel | thân bước CI tại H2 | EXIT=0, in `CLEAN_VERCEL_BUILD: PASS`, `GROK_EXTENSION_IN_STATIC: ABSENT`, `CHINAM_FOUNDATION_V2_IN_OUTPUT: PRESENT` ("added 315 packages") |
| Kiểm hàm máy chủ | `node scripts/check-built-server-grok-extension.mjs <…/.vercel/output>` | EXIT=0 |

**Số liệu `npm test`** (tổng kết node:test):

| Lần chạy | H2 | H1 (vòng 1) |
| --- | --- | --- |
| 1 (`scripts/**/*.test.mjs`) | `# tests 213` `# pass 213` `# fail 0` `# skipped 0` | `# tests 203` `# pass 203` |
| 2 (`src/lib/…`) | `# tests 59` `# pass 59` `# fail 0` | `# tests 59` `# pass 59` |
| 3 (`src/foundation/…`) | `# tests 103` `# pass 101` `# fail 0` `# skipped 2` | `# tests 103` `# pass 101` `# skipped 2` |

- Chênh lệch +10 ở lần chạy 1 khớp với số test REL-02. H1 có 6 test, H2 có 16: 13 test trong `check-live-no-grok-extension.test.mjs`, 1 test dấu hiệu, 2 test script CI. Cả 16 đều `ok`.
- Hai test bị bỏ qua (`CI production smoke: vite build`, `R2-F-04-m: native Chromium…`) giống H1 và M, do sandbox không có Chromium. PR không đụng hai test này.
- Workflow chạy `npm test` nên CI sẽ chạy cả 3 tệp test mới, gồm các test symlink, trên `ubuntu-latest` (`ANALYTICAL_CLAIM`, đọc workflow).
- `SOURCE_EVIDENCE: results/H2_pipeline/13_test.log`

**Script kiểm hàm máy chủ trên build sạch của H2** (nguyên văn):
```
PASS: VITE_GROK_EXTENSIONS=0 -> status 200, html 4999 bytes, grok-app-builder/extensions.js ABSENT (expected ABSENT)
PASS: VITE_GROK_EXTENSIONS unset (control) -> status 200, html 5076 bytes, grok-app-builder/extensions.js PRESENT (expected PRESENT)
BUILT_SERVER_GROK_EXTENSION_CHECK: PASS
```
Số byte giống hệt vòng 1. `SOURCE_EVIDENCE: results/H2_pipeline/17_check_built_server.log`

## 4. Việc 3 — R2C7-01

### 4.1 Mã mới làm gì (`ANALYTICAL_CLAIM`, đọc `scripts/check-live-no-grok-extension.mjs` tại H2)

Hàm `checkLiveNoGrokExtension` vẫn gọi fetch với `redirect: "follow"` và `AbortSignal.timeout(timeoutMs)` (mặc định 20 s). Sau đó hàm cho FAIL theo thứ tự sau:
1. không có URL cuối;
2. origin của URL cuối khác origin của URL đầu vào (so `URL.origin`, tức giao thức + host + cổng);
3. trạng thái không phải 2xx;
4. kiểu MIME không đúng `text/html` (chỉ xét phần trước dấu `;`, không phân biệt hoa thường);
5. thân rỗng;
6. HTML chứa `grok-app-builder/extensions.js`;
7. HTML **không chứa chuỗi con** `<title>CHỈNAM — Bàn vận hành</title>`.

Chỉ khi qua cả bảy điều kiện mới PASS. Dòng in ra luôn có dạng `PASS|FAIL: requested <url> -> final <URL cuối hoặc (none)> -> <lý do>`.

### 4.2 Harness 04 của vòng 1

Harness `v1/04_attack_live_check.mjs` không sửa, chạy trên H1 (đối chứng) rồi trên H2. `SOURCE_EVIDENCE: results/live_check/04_attack_live_check_H1_control.log`, `04_attack_live_check_H2.log`

**Đối chứng H1:** `TOTAL=43 FALSE_GREEN=11`. Kết quả này **trùng từng dòng** với log vòng 1 khi bỏ cột thời gian, tức harness tái hiện đúng.

**H2:** `TOTAL=43 FALSE_GREEN=3`

| Nhóm | Số ca | H1 | H2 |
| --- | --- | --- | --- |
| `inject` | 12 | 12/12 đỏ | 12/12 đỏ |
| `encoded (not emitted by platform)` | 4 | 4 XANH SAI | **3 XANH SAI** (`/upper-path`, `/entity-encoded-slash`, `/js-concatenated`); `/utf16-bom-with-script` nay đỏ vì không thấy dấu hiệu |
| `redirect` | 5 | 1 XANH SAI | **0 XANH SAI**; `redirect-other-origin-to-clean-nonapp` và `…-to-script` đỏ với lý do `redirected to another origin` |
| `2xx non-app` | 6 | 6 XANH SAI | **0 XANH SAI**: JSON, text, PNG, 204 đỏ do `content-type`; 200 rỗng đỏ do `empty body`; HTML khác đỏ do thiếu dấu hiệu |
| `hang` | 3 | đỏ sau ~20 s | đỏ sau 20 045 / 20 063 / 20 052 ms (`The operation was aborted due to timeout`) |
| `control` | 3 | đúng | đúng: trang app sạch và trang 5 MB sạch XANH, 500 đỏ |
| `args` | 10 | như vòng 1 | mã thoát trùng H1 ở cả 10 ca; thêm đối số thứ hai vẫn bị bỏ qua im lặng (xem O-4) |

Mọi dòng `PASS` ở H2 đều nêu URL cuối, ví dụ `PASS: requested http://127.0.0.1:PORT/clean-app -> final http://127.0.0.1:PORT/clean-app -> CHỈNAM app page (103 bytes) …`.

### 4.3 Harness 06 của vòng 1 (đột biến)

R2 kiểm trước rằng chuỗi đích của từng đột biến M1–M6 xuất hiện đúng 1 lần trong mã H2, nên mọi đột biến đều thực sự được áp dụng. `SOURCE_EVIDENCE: results/live_check/06_mutation_applicability_H2.txt`, `06_mutation_live_check_tests_H2.log`

| Đột biến | Vòng 1 (H1) | H2 |
| --- | --- | --- |
| M0 no-op (đối chứng) | xanh | xanh (13/13) |
| M1 bỏ timeout | SURVIVED | **CAUGHT** (1 fail) |
| M2 bỏ kiểm 2xx | CAUGHT | **CAUGHT** |
| M3 bỏ kiểm chuỗi script | CAUGHT | **CAUGHT** |
| M4 không theo chuyển hướng | SURVIVED | **CAUGHT** (2 fail) |
| M5 so không phân biệt hoa thường | survived (tương đương) | survived (tương đương) |
| M6 bỏ kiểm giao thức | survived (tương đương) | survived (tương đương) |

### 4.4 Đột biến bổ sung cho các nhánh mới (harness 12)

`SOURCE_EVIDENCE: results/live_check/12_mutation_v2_H2.log`. Bản sao gồm `scripts/`, `package.json` và `src/routes/index.tsx`; chạy 3 tệp test REL-02.

| Đột biến | Kết quả |
| --- | --- |
| N0 no-op, cả 3 tệp test | xanh (16/16) |
| L1 bỏ kiểm origin | CAUGHT |
| L2 bỏ kiểm `content-type` | CAUGHT |
| L3 bỏ kiểm thân rỗng | CAUGHT |
| L4 bỏ kiểm dấu hiệu | CAUGHT |
| L5 dòng PASS không in URL cuối | CAUGHT |
| L6 dấu hiệu nới thành `CHỈNAM` | CAUGHT |
| R1 đổi title trong `src/routes/index.tsx` | CAUGHT (test dấu hiệu đỏ) |
| L7 bỏ kiểm "không có URL cuối" | survived, tương đương: fetch thật luôn trả `response.url` |
| L8 thời hạn mặc định 20 s thành vô hạn | survived: test dùng `timeoutMs` nhỏ, không đụng mặc định. Thời hạn ở mức CLI đã đo ở 4.2 |
| L9 so MIME theo tiền tố `text/htm` | survived: chỉ khác với kiểu MIME bịa như `text/htmlx` |

### 4.5 Đầu-cuối trên hàm máy chủ thật đã build (harness 10)

Hàm máy chủ thật trong build sạch của H2 được phục vụ qua HTTP cục bộ, mỗi giá trị biến một tiến trình riêng, rồi chạy đúng CLI từ gốc checkout. `SOURCE_EVIDENCE: results/live_check/10_e2e_live_check_on_real_build_H2.log`

| `VITE_GROK_EXTENSIONS` (cùng một bản build) | `/` | `/?utm=1` | `/khong-ton-tai-r2` |
| --- | --- | --- | --- |
| `"0"` | **EXIT=0** `PASS: … -> final http://127.0.0.1:PORT/ -> CHỈNAM app page (4999 bytes) …` | EXIT=0 PASS | EXIT=1 `non-2xx status 404` |
| không đặt | **EXIT=1** `FAIL: … HTML contains grok-app-builder/extensions.js` | EXIT=1 | EXIT=1 `non-2xx status 404` |

HTML thật của `/` có **đúng 1** thẻ `<title>`, nằm ở ký tự 581. Thẻ đó chính là chuỗi dấu hiệu, xuất hiện đúng 1 lần, và cả HTML lẫn hằng trong script đều ở dạng NFC. Điều này giống nhau ở cả hai giá trị biến, tức script nền tảng không chèn thêm `<title>`.

Harness `v1/03` trên build H2 cho log **trùng hệt** log vòng 1:
- Trang 404 có title rút gọn `CHỈNAM`.
- Trang `/?install=1&platform=ios` là trang của nền tảng, title "Add Grok App to your Home Screen". Script live cho FAIL ở cả hai trang.
- Output tĩnh không có tệp HTML nào.

`SOURCE_EVIDENCE: results/probe/03_probe_built_function_paths_H2.log`; R2 đã `diff` với `results/probe/03_probe_built_function_paths.log` của gói vòng 1 và không thấy khác biệt.

Như vậy dấu hiệu khớp đúng đầu ra thật: không có đỏ sai trên app thật, và dòng PASS chỉ xuất hiện khi biến được đặt đúng.

### 4.6 Phép thử thêm của R2 (harness 09)

`SOURCE_EVIDENCE: results/live_check/09_attack_live_check_v2_H2.log`, `TOTAL=44`. Phần lớn ca chạy CLI thật. Riêng 7 ca origin chỉ khác giao thức cùng cổng, cổng mặc định tường minh và các biến thể chuẩn hóa host được thử bằng cách gọi hàm đã export với `fetchImpl` giả (ký hiệu FN), vì không dựng được bằng máy chủ thật trong sandbox.

| Nhóm | Ca | Kết quả |
| --- | --- | --- |
| Dấu hiệu nằm ngoài thẻ title thật (title thật là "Trang khác") | trong comment; trong chuỗi script; trong giá trị thuộc tính; trong `<template>`; trong `<body>` khi `<head>` không có title | **5/5 XANH** |
| | đối chứng: dấu hiệu đã escape (`&lt;title&gt;…`) | đỏ |
| Title khớp một phần hoặc khác chuẩn hóa | chỉ `CHỈNAM`; title dài hơn ("… (bản cũ)"); NFD; gạch nối `-`; gạch `–`; thẻ `<TITLE>` hoa; title có thuộc tính; thêm khoảng trắng; thực thể `&#7880;`/`&mdash;`; NBSP | **10/10 đỏ** (an toàn; app thật không sinh các dạng này, theo 4.5) |
| Nhiều thẻ title | "Trang khác" trước, dấu hiệu sau | **XANH** |
| | dấu hiệu trước, title khác sau | XANH (trình duyệt hiện title CHỈNAM) |
| | dấu hiệu trước, có script | đỏ |
| Trang nền tảng có title giống app | 404 / 502 / 503 có dấu hiệu | **3/3 đỏ** (`non-2xx`) |
| | 200 "This deployment is temporarily paused" có dấu hiệu | **XANH** |
| | 200 trang đăng nhập không có dấu hiệu | đỏ |
| Chuyển hướng cùng origin nhiều bước | 3 bước (302→301→307) tới app sạch; tuyệt đối cùng origin; chuỗi 19 bước | XANH, dòng PASS nêu URL cuối `/clean`, `/r-chain?n=0` |
| | 3 bước tới trang có script; 2 bước tới trang không phải app; chuỗi 25 bước (quá giới hạn 20 của fetch) | đỏ |
| | đi vòng qua origin khác rồi về lại origin ban đầu, trang sạch | XANH (nội dung được kiểm vẫn do origin được hỏi trả về) |
| Origin chỉ khác cổng | CLI `127.0.0.1:A` → `127.0.0.1:B`; FN `http://h/` → `http://h:8080/` | đỏ |
| Origin chỉ khác giao thức | FN `http://h:8443/` → `https://h:8443/`; FN `https://h/` → `http://h/` | đỏ |
| Khác giao thức và cổng (TLS thật, chứng chỉ tự ký) | CLI http → https; CLI https → http | đỏ |
| Khác host | CLI `127.0.0.1` → `localhost` | đỏ |
| Đối chứng chuẩn hóa | CLI https trực tiếp; CLI host `LOCALHOST`; FN `:443` tường minh; FN host viết hoa | XANH (đúng, cùng origin sau chuẩn hóa) |
| | FN host có dấu chấm cuối `h.example.` | đỏ (an toàn) |

Mọi dòng PASS của harness 09 đều có dạng `requested … -> final …` (`PASS_LINE_MISSING=0`).

### 4.7 Dấu hiệu có đủ để khẳng định "đúng là app" không

**Đủ, với nghĩa sau.** Dòng PASS khẳng định được rằng: phản hồi cuối là HTML 2xx, do **chính origin được hỏi** trả về, có chứa nguyên văn title của trang gốc CHỈNAM, và không chứa chuỗi script nền tảng.

Với mọi phản hồi "không phải app" thực tế mà R2 dựng được, script đều đỏ. Danh sách gồm: JSON, text, ảnh, 204, 200 rỗng, trang giữ chỗ, trang đăng nhập, trang nền tảng 404/502/503 (kể cả khi chèn title giống), chuyển hướng sang host, cổng hay giao thức khác, và vòng lặp chuyển hướng. `SOURCE_EVIDENCE` (4.2, 4.6).

Trên app thật, dấu hiệu khớp chính xác và duy nhất. `SOURCE_EVIDENCE` (4.5).

**Không đủ, với hai nghĩa chặt hơn** (`ANALYTICAL_CLAIM`, minh họa bằng `SOURCE_EVIDENCE` ở 4.6):

1. **Không phải phép kiểm cấu trúc.** Script so chuỗi con, không phân tích HTML. Một trang 2xx cùng origin cố ý chứa nguyên văn chuỗi dấu hiệu ở chỗ khác thẻ title thật vẫn cho XANH: 7 ca ở 4.6. Muốn xảy ra trong thực tế, trang đó phải chép đúng từng byte chuỗi `<title>CHỈNAM — Bàn vận hành</title>` (có dấu tiếng Việt, gạch `—`, thẻ mở và đóng) mà lại không phải app. R2 không tìm được nguồn thực tế nào sinh ra trang như vậy:
   - Hàm máy chủ thật chỉ sinh 1 title (4.5).
   - Trang 404 và trang cài đặt của nền tảng không mang dấu hiệu (4.5).
   - Trang nền tảng giả lập mang dấu hiệu nhưng trả non-2xx thì đỏ (4.6).

   Trang hệ thống thật của Vercel (paused, not found, bảo vệ) trả mã nào và có chèn title của app không thì R2 không kiểm được vì không tới được vercel.com: `CHƯA ĐỦ BẰNG CHỨNG`. R2 xếp các ca này là **giới hạn đã biết**, cùng cách vòng 1 xếp các dạng mã hóa mà nền tảng không sinh ra, **không phải finding**.
2. **Không chứng minh được bản build hay commit.** Mọi bản triển khai CHỈNAM, kể cả bản build từ commit cũ hay từ nhánh khác, đều mang cùng title. Phần "build từ `main`" của REL-01 dựa vào bước 4 của TASK_QUEUE ("Deploy from `main`") và việc "Record result and SHA". Sổ vận hành đặt đúng chữ "on the deployed site built from `main`" trong điều kiện đóng REL-01 (mục 6). Đây là quan sát cho Owner (O-1), không phải finding, và R2 không đề xuất mở rộng phạm vi.

### 4.8 Đối chiếu 4 điều kiện đóng R2C7-01 (mục 8 báo cáo vòng 1)

| # | Điều kiện | Kết quả | Nhãn |
| --- | --- | --- | --- |
| 1 | Thoát khác 0 khi: `content-type` không phải `text/html`; thân rỗng (kể cả 204); HTML thiếu dấu hiệu dương tính; chuyển hướng kết thúc ở origin khác | Đạt: 4.2, 4.6; L1–L4 CAUGHT | `SOURCE_EVIDENCE` |
| 2 | In URL cuối đã kiểm | Đạt: mọi dòng PASS/FAIL có `-> final …`; L5 CAUGHT | `SOURCE_EVIDENCE` |
| 3 | Test đơn vị với máy chủ giả cho từng trường hợp ở điểm 1, một ca chuyển hướng, một ca treo dùng `timeoutMs` nhỏ | Đạt. Tệp test có: JSON, text với thân là trang app, thiếu `content-type`, 200 rỗng, 204, HTML không phải app, chuyển hướng cùng origin (XANH), chuyển hướng khác origin (ĐỎ), máy chủ treo với `timeoutMs: 300` và chặn 5 s. Cả 13 test `ok` | `SOURCE_EVIDENCE` (`13_test.log`) + `ANALYTICAL_CLAIM` (đọc test) |
| 4 | Harness 04: `FALSE_GREEN` chỉ còn ở nhóm `encoded`, 0 ở `2xx non-app` và `redirect`. Harness 06: M1–M4 `CAUGHT` | Đạt: 3 ca, đều `encoded`; M1–M4 CAUGHT | `SOURCE_EVIDENCE` |

**R2C7-01: CLOSED.**

## 5. Việc 4 — R2C7-02

### 5.1 Mã mới (`ANALYTICAL_CLAIM`, đọc `scripts/is-main-module.mjs`)

`isMainModule(metaUrl, argv1 = process.argv[1])` làm như sau:
- trả `false` nếu không có `argv1`;
- so `realpathSync(fileURLToPath(metaUrl))` với `realpathSync(argv1)`, không phân biệt hoa thường khi chạy trên `win32`;
- trả `false` nếu có ngoại lệ.

Cả hai script mới gọi `if (isMainModule(import.meta.url)) …main()`. Ba script cũ không đổi, đúng quyết định của Owner.

### 5.2 Harness 07 của vòng 1

`SOURCE_EVIDENCE: results/live_check/07_symlink_guard_live_H2.log`

| Cách gọi (trang **có** script) | Vòng 1 (H1) | H2 |
| --- | --- | --- |
| đường dẫn thật | EXIT=1 | EXIT=1 `FAIL: … HTML contains …` |
| **đường dẫn tuyệt đối qua symlink** | **EXIT=0, 0 byte** | **EXIT=1** `FAIL: … HTML contains …` (120 byte) |
| qua symlink + `--preserve-symlinks-main` | EXIT=1 | EXIT=1 |
| cd vào symlink, đường dẫn tương đối | EXIT=1 | EXIT=1 |

### 5.3 Harness 02 của vòng 1 (script CI, fail-closed)

`SOURCE_EVIDENCE: results/ci_step/02_failclosed_built_server_check_H2.log`, `02_diff_round1_vs_H2.txt`
- Các ca A–M cho kết quả và nội dung **trùng hệt** vòng 1 sau khi chuẩn hóa đường dẫn tạm và thời gian:
  - A, B, C, D, E, F, G, H, J, L: EXIT=1;
  - K (treo): EXIT=1 sau 61 s;
  - I và M (build sạch thật): EXIT=0.
- **Ca N** (gọi qua symlink trên thư mục **rỗng**): vòng 1 cho EXIT=0, 0 byte. H2 cho **EXIT=1** `FAIL: missing built server function …`.

### 5.4 Ma trận cách gọi của R2 (harness 11)

Mỗi script được gọi theo 19 cách, mỗi cách chạy với một đầu vào ĐỎ và một đầu vào XANH:
- Script live: trang app có script / trang app sạch.
- Script CI: thư mục output rỗng / output giả tôn trọng biến.

Bất biến cần giữ: **thoát 0 thì phải có dòng PASS của phép kiểm**. `SOURCE_EVIDENCE: results/live_check/11_symlink_matrix_H1_control.log`, `11_symlink_matrix_H2.log`

Các cách gọi:
- V01 đường dẫn tuyệt đối thật;
- V02 tương đối từ gốc repo;
- V03 tương đối có `./` và `..`;
- V04 symlink tệp tuyệt đối;
- V05 symlink tệp có đích tương đối;
- V06 symlink thư mục `scripts/`;
- V07 cd vào symlink gốc repo;
- V08 đường dẫn tương đối qua symlink thư mục;
- V09 chuỗi symlink tệp 2 bước;
- V10 chuỗi symlink thư mục 2 bước;
- V11 chuỗi thư mục tới gốc repo;
- V12 symlink tệp không đuôi `.mjs`;
- V13 `--preserve-symlinks-main` + symlink tệp;
- V14 `--preserve-symlinks --preserve-symlinks-main` + symlink thư mục;
- V15 thư mục có dấu cách, dấu tiếng Việt, `%20`, `#`;
- V16 symlink tới thư mục đó;
- V17 bản sao hard link;
- V18 `/proc/self/cwd/scripts/…`;
- V19 dấu `//` thừa.

| | H1 (đối chứng) | H2 |
| --- | --- | --- |
| "!! THOÁT 0 KHÔNG KIỂM" | **40/76**: V04, V05, V06, V08, V09, V10, V11, V12, V16, V18 × đỏ/xanh × 2 script, mọi ca 0 byte đầu ra | **0/76** |
| Đúng kỳ vọng | 36/76 | 72/76; 18/18 dòng PASS của script live có dạng `requested … -> final …` |
| Đỏ do lỗi nạp module | 0 | 4/76: V13 × đỏ/xanh × 2 script, EXIT=1 `ERR_MODULE_NOT_FOUND` (xem O-2) |

### 5.5 Cách gọi bất thường (harness 14)

Mỗi cách gọi được chạy với trang **có** script. `SOURCE_EVIDENCE: results/live_check/14_guard_exotic_invocations_H2.log`, `…_H1_control.log`

| Cách gọi | H1 | H2 |
| --- | --- | --- |
| `node /dev/stdin <url> < script` | EXIT=0, 0 byte | EXIT=1 `FAIL: … HTML contains …` |
| `cat script \| node --input-type=module - <url>` | EXIT=0, 0 byte | EXIT=1 (`ERR_MODULE_NOT_FOUND`) |
| `node -e "await import('./scripts/…')" <url>` | EXIT=0, 0 byte | EXIT=0, 0 byte |

Ca cuối là một chương trình khác nạp script như thư viện, không phải gọi script. Khi đó `argv[1]` là URL nên `realpathSync` ném lỗi và nhánh `catch` trả `false`. Không chạy `main()` khi bị import là hành vi đúng của guard. Ngoài cách này, R2 không tìm được đường gọi script nào chạm nhánh `catch`, vì Node đã tự realpath chính đường dẫn đó khi nạp script (`ANALYTICAL_CLAIM`; đột biến G6 ở 5.6 sống vì nhánh này không chạm được trong test). Tiêu chí đạt trong sổ vận hành cũng đòi dòng `PASS:` chứ không chỉ mã thoát 0, nên cách gọi này không thể bị tính là đạt.

### 5.6 Test có giữ được bản sửa không (harness 12)

`SOURCE_EVIDENCE: results/live_check/12_mutation_v2_H2.log`

| Đột biến | Kết quả |
| --- | --- |
| G1 bỏ realpath cả hai phía | CAUGHT |
| G2 guard luôn đúng | CAUGHT |
| G3 guard luôn sai | CAUGHT |
| G4 bỏ realpath phía `argv1` | CAUGHT |
| B1 script CI quay về guard so chuỗi cũ | CAUGHT (2/2 test đỏ) |
| B2 script live quay về guard so chuỗi cũ | CAUGHT |
| G5 bỏ realpath phía `import.meta.url` | survived, tương đương: Node đã đặt `import.meta.url` theo realpath |
| G6 nhánh `catch` trả `true` | survived: nhánh lỗi, không chạm được trong test (5.5) |

### 5.7 Đối chiếu điều kiện đóng R2C7-02, cách (a) Owner đã chọn

| Điều kiện | Kết quả | Nhãn |
| --- | --- | --- |
| Hai script mới không thể thoát 0 khi chưa chạy phép kiểm (so khớp realpath) | Đạt: 5.2, 5.3, 5.4 (0/76), 5.5 | `SOURCE_EVIDENCE` |
| Có test gọi qua symlink | Đạt: test live (symlink tệp, symlink thư mục; ca đỏ thoát 1, ca xanh có dòng PASS); test CI (đường dẫn thật, symlink tệp, symlink thư mục; rỗng thoát 1, tốt in PASS); cả hai đều `ok` trong `npm test` và bắt được B1, B2, G1, G4 | `SOURCE_EVIDENCE` |
| Ba script cũ không sửa ở PR này, chỉ ghi quan sát | Đạt: blob `brand-check.mjs`, `preview.mjs`, `write-atomic.mjs` không đổi (không có trong diff). `TASK_QUEUE_V1.md` có mục OBS-01 ghi đúng vị trí `brand-check.mjs:196`, `preview.mjs:332`, `write-atomic.mjs:71` (R2 đã đối chiếu từng dòng) và ghi rõ "Not changed in PR #7 by Owner decision" | `SOURCE_EVIDENCE` (`results/diff/05_ops_records_H2.txt`) |

Windows: guard so không phân biệt hoa thường trên `win32`. R2 không chạy được Windows nên phần này là `CHƯA ĐỦ BẰNG CHỨNG`; CI chạy `ubuntu-latest`.

**R2C7-02: CLOSED.**

## 6. Việc 5 — Sổ vận hành

| Yêu cầu | Trạng thái tại H2 | Nhãn |
| --- | --- | --- |
| REVIEW_LOG có dòng vòng 1, kèm liên kết bình luận và SHA-256 báo cáo | Dòng PR #7: SHA `a1aa7005…`, "**PR #7 — R2 vòng 1: CHANGES REQUIRED** (waiver W-01)", tóm tắt R2C7-01/02/03 kèm mức, "Report SHA-256 `060a84dd…e32e`" (khớp), liên kết `…/pull/7#issuecomment-6788374508`. Dòng nằm sau dòng PR #6, đúng thứ tự | `SOURCE_EVIDENCE` (đọc tệp, `results/diff/05_ops_records_H2.txt`) |
| Liên kết đó trỏ đúng báo cáo vòng 1 | API trả 403 (giới hạn lượt gọi). R2 đọc trang HTML công khai của PR #7: bình luận `6788374508` có thật, là bình luận duy nhất trên trang, do `tranngocthang12-gif` (Owner) đăng. Đầu bình luận ghi "SHA-256 báo cáo: `060a84dd…e32e`"; nội dung chứa `MIỄN TRỪ W-01`, SHA `a1aa7005…` và `KẾT LUẬN: CHANGES REQUIRED` | `SOURCE_EVIDENCE: results/github_api/` |
| PROJECT_STATE, mục Deployment, ghi đúng tiêu chí đạt: thoát 0 **và** có dòng PASS kèm URL cuối, chạy từ gốc repo | Ghi đủ ba ý: "from the repository root"; chỉ đạt khi "exits 0 **and** prints a line starting with `PASS:` that names the final URL checked". Có liệt kê 7 điều kiện FAIL khớp mã 4.1 (sổ không liệt kê ba điều kiện phụ là URL sai, giao thức không hỗ trợ và thiếu URL cuối; cả ba đều làm script đỏ, nên không gây đóng sai). Định dạng dòng PASS ghi trong sổ khớp đầu ra thật (4.5) | `SOURCE_EVIDENCE` (đọc tệp) + `ANALYTICAL_CLAIM` (đối chiếu mã) |
| REL-01 chưa đóng | "**REL-01 — OPEN until a live deployment from `main` is verified.**" Điều kiện đóng nay viết theo dòng PASS kèm URL cuối "on the deployed site built from `main`" | `SOURCE_EVIDENCE` |
| REL-02 chưa đóng | Trạng thái vẫn là "GIẢM THIỂU BẰNG CÀI ĐẶT — chờ kiểm bản chạy thật", có thêm ghi chú vòng 1 CHANGES REQUIRED và "awaiting R2 round 2". Không dòng nào ghi REL-01 hay REL-02 đã đóng; chữ "closed" chỉ xuất hiện trong định nghĩa "Xong" (điều kiện tương lai) | `SOURCE_EVIDENCE` (`results/diff/05_ops_records_H2.txt`) |
| TASK_QUEUE | Bước 5: "From the repository root … only on exit 0 with a `PASS:` line naming the final URL, close REL-01 and REL-02" (PENDING). Bước 1 ghi vòng 1 CHANGES REQUIRED và chờ R2 chấm lại. Bước 2 (Owner gộp) vẫn PENDING | `SOURCE_EVIDENCE` |
| Bối cảnh vòng 1 giữ nguyên | `AGENTS.project.md` không đổi (blob trùng H1). Phần `VITE_GROK_EXTENSIONS=0` cho Production và Preview cùng các quyết định D-1..D-3 không bị đụng (diff chỉ đổi các dòng nêu trên) | `SOURCE_EVIDENCE` |

## 7. Việc 6 — Hồi quy các điểm đã đạt ở vòng 1

| Điểm | Kết quả | Nhãn |
| --- | --- | --- |
| Bước CI mới (thân bước, thứ tự, không có `if:` hay `continue-on-error`) | Blob workflow H2 **trùng hệt** H1 (`4262ae5…`), nên mọi kết luận vòng 1 về YAML, gồm harness 05 về thư mục `$RUNNER_TEMP`, giữ nguyên. R2 không chạy lại harness 05 vì đầu vào của nó (thân bước ở M và ở H1) không đổi. Thân bước build sạch chạy trên H2: PASS (mục 3) | `SOURCE_EVIDENCE` (blob hash, `16_clean_vercel_build.log`) |
| Script CI phân biệt hai trường hợp, có đối chứng, fail-closed | Đổi duy nhất là dòng guard (+3/−1). Trên build thật: 4999 byte ABSENT, 5076 byte PRESENT. Harness 02 trên ca A–M trùng vòng 1; ca N nay đỏ | `SOURCE_EVIDENCE` (mục 3, 5.3) |
| Phạm vi tệp | 0 tệp nền tảng, `src/`, `package*.json`, `vercel.json`, `.github/` bị đổi giữa M và H2 | `SOURCE_EVIDENCE` (mục 2.2) |
| Thời hạn chờ của script live | Ba kiểu treo đỏ trong 20,05–20,06 s ở mức CLI (4.2). Nay có thêm test đơn vị (M1 CAUGHT) | `SOURCE_EVIDENCE` |
| Thời hạn chờ của script CI | Ca K đỏ sau 61 s (`timeout: 60_000` không đổi) | `SOURCE_EVIDENCE` |
| Chèn script nguyên văn (12 biến thể) | 12/12 đỏ như vòng 1 | `SOURCE_EVIDENCE` |
| Pipeline | Mọi bước EXIT=0. Lint giữ đúng 1 cảnh báo cũ. Test 213/59/101+2 skip, 0 fail | `SOURCE_EVIDENCE` |

Không thấy hồi quy.

## 8. R2C7-03

Owner đã chấp nhận để nguyên các commit cũ. Cả 4 commit mới tuân thủ quy định "thông điệp commit không có liên kết phiên hay địa chỉ thư" (mục 2.3, `SOURCE_EVIDENCE`). R2 ghi **R2C7-03: CLOSED theo quyết định chấp nhận của Owner**. Mỗi commit cũ `2283b79`, `a427f00`, `a1aa700` vẫn còn một trailer `Claude-Session` trong lịch sử (R2 đếm lại bằng `git log`; 4 commit mới đều 0). `SOURCE_EVIDENCE: results/diff/06_session_trailers_old_vs_new.txt` Đây là hệ quả của quyết định không viết lại lịch sử, không phải hồi quy.

## 9. Quan sát (không phải finding, không đề xuất mở rộng phạm vi)

- **O-1 (dấu hiệu không chứng minh nguồn build).** PASS chứng minh "origin này đang phục vụ trang CHỈNAM không có script nền tảng". PASS không chứng minh bản đó build từ `main` hay từ commit nào. Khi đóng REL-01 theo bước 5, Owner cần tự đối chiếu rằng URL là bản triển khai từ `main` và ghi SHA như TASK_QUEUE đã ghi. Ngoài ra, chuỗi con dấu hiệu nằm ở chỗ khác thẻ title vẫn cho PASS (4.6, 4.7). `ANALYTICAL_CLAIM`
- **O-2 (`--preserve-symlinks-main` với symlink tệp đặt ngoài `scripts/`).** Vì hai script nay import `./is-main-module.mjs`, cách gọi này làm Node tìm module cạnh symlink rồi báo `ERR_MODULE_NOT_FOUND`, thoát 1. Kết quả là đỏ, an toàn, nhưng không kiểm được. Ở H1 cách gọi này chạy được. Cách gọi theo sổ vận hành (V02) và mọi cách khác trong ma trận đều chạy đúng. `SOURCE_EVIDENCE` (5.4)
- **O-3 (test dấu hiệu ghim mã nguồn, không ghim đầu ra build).** `check-live-marker.test.mjs` kiểm chuỗi `title: "CHỈNAM — Bàn vận hành"` trong `src/routes/index.tsx`, không kiểm HTML đã render. Nếu sau này cách render title thay đổi, ví dụ thêm thuộc tính vào thẻ, script live sẽ đỏ sai. Đây là hướng an toàn, và harness 10 cho thấy hiện tại khớp. `SOURCE_EVIDENCE` (4.5) + `ANALYTICAL_CLAIM`
- **O-4 (đối số thừa, từ vòng 1).** Đối số thứ hai trở đi vẫn bị bỏ qua im lặng. Dòng PASS chỉ nêu URL đầu, nên không gây hiểu nhầm về URL đã kiểm. `SOURCE_EVIDENCE` (4.2)
- **O-5 (Preview có Deployment Protection).** Nếu Vercel chuyển hướng Preview sang trang đăng nhập ở origin khác, script nay **đỏ** (4.6, ca khác host), nên không còn lỗ của vòng 1. Hệ quả là Preview đang được bảo vệ sẽ không kiểm được bằng script. Hành vi thật của Vercel: `CHƯA ĐỦ BẰNG CHỨNG`.
- **O-6 (đếm "bytes").** Số trong dòng PASS ("4999 bytes") là độ dài chuỗi JS, không phải số byte UTF-8. Đây là cách ghi có từ vòng 1 và không ảnh hưởng phép kiểm. `ANALYTICAL_CLAIM`

## 10. Những gì R2 không kiểm được

- GitHub Actions thật và bước F-04 (Chromium). R2 không đọc log CI. Phần "CI chạy 3 tệp test mới trên `ubuntu-latest`" là `ANALYTICAL_CLAIM`.
- Vercel thật: biến lúc chạy, trang hệ thống, Deployment Protection. Tất cả là `CHƯA ĐỦ BẰNG CHỨNG`, và đó là lý do REL-01 và REL-02 chỉ đóng sau khi kiểm bản chạy thật.
- Windows và macOS (chữ hoa/thường ổ đĩa, hệ tệp không phân biệt hoa thường): `CHƯA ĐỦ BẰNG CHỨNG`.
- Nội dung bình luận qua API GitHub (403). R2 thay bằng trang HTML công khai (mục 6).

## 11. Gói bằng chứng

`R2_CHINAM_PR7_V2_REVIEW_PACKAGE.zip` gồm:
- `R2_CHINAM_PR7_V2_VERDICT_FROZEN.md` (tệp này) và `R2_CHINAM_PR7_V2_VERDICT_FROZEN.sha256`;
- `SHA256SUMS.txt`, ghi SHA-256 của mọi tệp trong gói trừ chính nó;
- `harness/`:
  - `v1/`: harness vòng 1, nguyên byte;
  - `00`, `09`–`14`: phép thử mới;
  - `README.md`: thứ tự tái hiện từ repo công khai;
- `results/`: log nguyên văn của mọi phép chạy kể trên (`00_environment.txt`, `01_round1_package_integrity.txt`, `diff/`, `H2_pipeline/`, `probe/`, `live_check/`, `ci_step/`, `github_api/`). Ngoại lệ duy nhất: địa chỉ IP ra ngoài của sandbox trong phản hồi 403 của api.github.com đã được che trước khi đóng gói vì gói sẽ công khai (`results/github_api/README_redaction.txt`).

---

## KẾT LUẬN: MERGEABLE (R2C7-01, R2C7-02 CLOSED, không hồi quy)

Đầu PR được chấm là `a867864073ca2fa11b725e53e088506da1584417`.

- **Phạm vi:** 9 tệp, tất cả phục vụ R2C7-01, R2C7-02 hoặc sổ vận hành. Không đổi tệp nền tảng, `src/`, `package.json`, `package-lock.json` hay workflow. Không thêm thư viện. Thông điệp 4 commit mới sạch.
- **Pipeline trên H2:** xanh hoàn toàn, test 213 + 59 + 101 (2 skip như cũ), 0 fail. Script CI cho ABSENT/PRESENT với 4999/5076 byte trên build thật.
- **R2C7-01:**
  - Harness 04: `FALSE_GREEN` từ 11 xuống 3, cả 3 thuộc nhóm `encoded`; 0 ở `2xx non-app` và `redirect`.
  - Harness 06: M1–M4 CAUGHT.
  - Dấu hiệu khớp chính xác HTML thật. Trên cùng bản build, `=0` cho PASS kèm URL cuối, không đặt biến cho FAIL.
  - Phép thử thêm: origin chỉ khác cổng hoặc giao thức đều đỏ; biến thể title đều đỏ; chuyển hướng cùng origin nhiều bước cho đúng kết quả.
  - Giới hạn so chuỗi con được ghi ở 4.7 và O-1.
  - **CLOSED.**
- **R2C7-02:**
  - Ca symlink của vòng 1 (harness 07, ca N harness 02) nay đỏ.
  - Ma trận 19 cách gọi: 0/76 ca thoát 0 mà không kiểm (H1: 40/76).
  - Test qua symlink tệp và thư mục có trong `npm test` và bắt được đột biến quay về guard cũ.
  - **CLOSED.**
- **R2C7-03:** CLOSED theo quyết định chấp nhận của Owner; các commit mới tuân thủ.
- **Sổ vận hành:** REVIEW_LOG có dòng vòng 1 với liên kết đã kiểm và SHA-256 đúng. PROJECT_STATE ghi đúng tiêu chí đạt. REL-01 và REL-02 vẫn OPEN.
- **Không có finding mới.** Các quan sát O-1..O-6 không chặn và không đòi sửa ở PR này.

Owner giữ quyền gộp.
