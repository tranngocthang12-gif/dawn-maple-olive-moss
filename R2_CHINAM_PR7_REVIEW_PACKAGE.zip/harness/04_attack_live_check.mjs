#!/usr/bin/env node
// R2 harness — thử phá scripts/check-live-no-grok-extension.mjs của H bằng máy chủ giả cục bộ.
// Mỗi ca chạy đúng CLI mà Owner sẽ chạy (node <script> <url>), đo mã thoát và thời gian.
// "should" = kết quả an toàn mong đợi: RED (exit != 0) hoặc GREEN (exit 0).
// Ca nào exit 0 trong khi "should" = RED là một đường XANH SAI.
//
// Cách dùng: node 04_attack_live_check.mjs <checkout H>
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { gzipSync } from "node:zlib";
import { resolve } from "node:path";

const H = resolve(process.argv[2] ?? ".");
const SCRIPT = `${H}/scripts/check-live-no-grok-extension.mjs`;
const SRC = "https://grok.com/grok-app-builder/extensions.js";
const APP = (head) => `<!doctype html><html lang="vi"><head><title>CHỈNAM — Bàn vận hành</title>${head}</head><body>app</body></html>`;
const html = (body, status = 200, extra = {}) => ({ status, headers: { "content-type": "text/html; charset=utf-8", ...extra }, body });

// --- máy chủ B (khác origin) để thử chuyển hướng sang nơi khác
const other = createServer((req, res) => {
  if (req.url === "/with-script") { res.writeHead(200, { "content-type": "text/html" }); res.end(APP(`<script src="${SRC}" defer></script>`)); return; }
  res.writeHead(200, { "content-type": "text/html" });
  res.end("<!doctype html><html><head><title>Log in</title></head><body>Some other site / login wall</body></html>");
});
await new Promise((r) => other.listen(0, "127.0.0.1", r));
const OTHER = `http://localhost:${other.address().port}`; // dùng "localhost" để khác origin với 127.0.0.1

const big = (n, needleAtEnd) => APP("") + "<!--" + "x".repeat(n) + "-->" + (needleAtEnd ? `<script src="${SRC}"></script>` : "");

const ROUTES = {
  // ===== Biến thể chèn script (should RED)
  "/query-string": html(APP(`<script src="${SRC}?v=123&t=9" defer></script>`)),
  "/upper-tag-attr": html(APP(`<SCRIPT DEFER SRC="${SRC}"></SCRIPT>`)),
  "/upper-host": html(APP(`<script src="https://GROK.COM/grok-app-builder/extensions.js"></script>`)),
  "/attr-order": html(APP(`<script defer data-project-id="p1" type="text/javascript" src='${SRC}'></script>`)),
  "/module-script": html(APP(`<script type="module" src="${SRC}"></script>`)),
  "/link-preload": html(APP(`<link rel="preload" as="script" href="${SRC}">`)),
  "/inline-import": html(APP(`<script>import("${SRC}")</script>`)),
  "/protocol-relative": html(APP(`<script src="//grok.com/grok-app-builder/extensions.js"></script>`)),
  "/in-body-end": html(`<!doctype html><html><head><title>CHỈNAM</title></head><body>app<script src="${SRC}"></script></body></html>`),
  "/huge-5MB-needle-at-end": html(big(5_000_000, true)),
  "/huge-chunked-needle-split": { chunked: [APP("").slice(0, -14) + '<script src="https://grok.com/grok-app-', "builder/exten", 'sions.js"></script></head><body>x</body></html>'] },
  "/gzip-with-script": { status: 200, headers: { "content-type": "text/html", "content-encoding": "gzip" }, body: gzipSync(APP(`<script src="${SRC}"></script>`)) },
  // biến thể mã hoá: trình duyệt vẫn tải script, phép so chuỗi không thấy (nền tảng KHÔNG sinh ra dạng này)
  "/upper-path": html(APP(`<script src="https://grok.com/GROK-APP-BUILDER/EXTENSIONS.JS"></script>`)),
  "/entity-encoded-slash": html(APP(`<script src="https://grok.com/grok-app-builder&#x2F;extensions.js"></script>`)),
  "/js-concatenated": html(APP(`<script>var s=document.createElement("script");s.src="https://grok.com/grok-app-"+"builder/extensions.js";document.head.appendChild(s)</script>`)),
  "/utf16-bom-with-script": { status: 200, headers: { "content-type": "text/html" }, body: Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(APP(`<script src="${SRC}"></script>`), "utf16le")]) },

  // ===== Chuyển hướng
  "/redirect-same-origin-to-script": { status: 302, headers: { location: "/query-string" }, body: "" },
  "/redirect-other-origin-to-script": { status: 302, headers: { location: `${OTHER}/with-script` }, body: "" },
  "/redirect-other-origin-to-clean-nonapp": { status: 302, headers: { location: `${OTHER}/login` }, body: "" },
  "/redirect-loop": { status: 302, headers: { location: "/redirect-loop" }, body: "" },
  "/redirect-to-file-scheme": { status: 302, headers: { location: "file:///etc/hostname" }, body: "" },

  // ===== 2xx nhưng không phải trang app (should RED: chưa kiểm được app)
  "/json-200": { status: 200, headers: { "content-type": "application/json" }, body: '{"ok":true}' },
  "/text-200": { status: 200, headers: { "content-type": "text/plain" }, body: "hello" },
  "/empty-200": { status: 200, headers: { "content-type": "text/html" }, body: "" },
  "/no-content-204": { status: 204, headers: {}, body: "" },
  "/png-200": { status: 200, headers: { "content-type": "image/png" }, body: Buffer.from([0x89, 0x50, 0x4e, 0x47]) },
  "/html-200-not-the-app": html("<!doctype html><html><head><title>Deployment placeholder</title></head><body>Coming soon</body></html>"),

  // ===== Đối chứng
  "/clean-app": html(APP("")),
  "/huge-5MB-clean": html(big(5_000_000, false)),
  "/status-500": html(APP(""), 500),
};

const server = createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  if (u.pathname === "/hang-no-headers") return; // không bao giờ trả lời
  if (u.pathname === "/hang-after-headers") { res.writeHead(200, { "content-type": "text/html" }); res.write("<!doctype html><html><head>"); return; }
  if (u.pathname === "/trickle-forever") {
    res.writeHead(200, { "content-type": "text/html" });
    const t = setInterval(() => res.write(" "), 500);
    req.on("close", () => clearInterval(t));
    return;
  }
  const r = ROUTES[u.pathname];
  if (!r) { res.writeHead(404, { "content-type": "text/html" }); res.end("nf"); return; }
  if (r.chunked) {
    res.writeHead(200, { "content-type": "text/html" });
    let i = 0;
    const next = () => { if (i < r.chunked.length) { res.write(r.chunked[i++]); setTimeout(next, 30); } else res.end(); };
    next();
    return;
  }
  res.writeHead(r.status, r.headers);
  res.end(r.body);
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const BASE = `http://127.0.0.1:${server.address().port}`;

function cli(args, cwd = H) {
  return new Promise((resolveP) => {
    const t0 = Date.now();
    const child = spawn(process.execPath, [SCRIPT, ...args], { cwd, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    child.stdout.on("data", (c) => (out += c));
    child.stderr.on("data", (c) => (out += c));
    const kill = setTimeout(() => child.kill("SIGKILL"), 90_000);
    child.on("close", (code, signal) => { clearTimeout(kill); resolveP({ code, signal, ms: Date.now() - t0, out: out.trim().split("\n")[0].replace(/127\.0\.0\.1:\d+|localhost:\d+/g, (m) => m.split(":")[0] + ":PORT").slice(0, 220) }); });
  });
}

const CASES = [
  ...["/query-string", "/upper-tag-attr", "/upper-host", "/attr-order", "/module-script", "/link-preload", "/inline-import",
      "/protocol-relative", "/in-body-end", "/huge-5MB-needle-at-end", "/huge-chunked-needle-split", "/gzip-with-script"].map((p) => [p, "RED", "inject"]),
  ...["/upper-path", "/entity-encoded-slash", "/js-concatenated", "/utf16-bom-with-script"].map((p) => [p, "RED", "encoded (not emitted by platform)"]),
  ["/redirect-same-origin-to-script", "RED", "redirect"],
  ["/redirect-other-origin-to-script", "RED", "redirect"],
  ["/redirect-other-origin-to-clean-nonapp", "RED", "redirect"],
  ["/redirect-loop", "RED", "redirect"],
  ["/redirect-to-file-scheme", "RED", "redirect"],
  ...["/json-200", "/text-200", "/empty-200", "/no-content-204", "/png-200", "/html-200-not-the-app"].map((p) => [p, "RED", "2xx non-app"]),
  ["/hang-no-headers", "RED", "hang"],
  ["/hang-after-headers", "RED", "hang"],
  ["/trickle-forever", "RED", "hang"],
  ["/clean-app", "GREEN", "control"],
  ["/huge-5MB-clean", "GREEN", "control"],
  ["/status-500", "RED", "control"],
];

const rows = [];
for (const [path, should, group] of CASES) {
  const r = await cli([`${BASE}${path}`]);
  const got = r.code === 0 ? "GREEN" : "RED";
  rows.push({ group, path, should, got, code: r.code, ms: r.ms, out: r.out, falseGreen: should === "RED" && got === "GREEN" });
}
// ===== Đối số
for (const [label, args, should] of [
  ["no-argument", [], "RED"],
  ["empty-string", [""], "RED"],
  ["garbage", ["not a url"], "RED"],
  ["ftp", ["ftp://example.invalid/"], "RED"],
  ["file-scheme", ["file:///etc/hostname"], "RED"],
  ["javascript-scheme", ["javascript:alert(1)"], "RED"],
  ["credentials-in-url", [`http://u:p@127.0.0.1:${server.address().port}/clean-app`], "RED?"],
  ["host-without-path", [BASE], "?"],
  ["extra-args-ignored", [`${BASE}/clean-app`, `${BASE}/query-string`], "?"],
  ["unresolvable-host", ["https://r2-khong-ton-tai.invalid/"], "RED"],
]) {
  const r = await cli(args);
  const got = r.code === 0 ? "GREEN" : "RED";
  rows.push({ group: "args", path: label, should, got, code: r.code, ms: r.ms, out: r.out, falseGreen: should === "RED" && got === "GREEN" });
}

for (const r of rows) {
  console.log(
    `${r.falseGreen ? "!! XANH SAI" : "   ok      "} | ${r.group.padEnd(34)} | ${r.path.padEnd(40)} | should=${r.should.padEnd(5)} got=${r.got.padEnd(5)} exit=${String(r.code).padEnd(4)} ${String(r.ms).padStart(6)}ms | ${r.out}`,
  );
}
console.log(`TOTAL=${rows.length} FALSE_GREEN=${rows.filter((r) => r.falseGreen).length}`);
server.closeAllConnections?.(); server.close(); other.close();
