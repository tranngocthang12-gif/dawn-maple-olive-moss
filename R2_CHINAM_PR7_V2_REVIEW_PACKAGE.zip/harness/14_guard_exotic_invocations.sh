#!/usr/bin/env bash
# R2 vòng 2 — nhánh catch của scripts/is-main-module.mjs (trả false => main() không chạy => thoát 0 im lặng)
# có chạm tới được bằng cách gọi bất thường nào không? Mỗi cách chạy với một trang CÓ script (phải ĐỎ).
# Cách dùng: bash 14_guard_exotic_invocations.sh <checkout>
set -u
H="$(cd "$1" && pwd -P)"; S=scripts/check-live-no-grok-extension.mjs
W="$(mktemp -d)"
cat >"$W/srv.mjs" <<'JS'
import { createServer } from "node:http";
const s = createServer((q, r) => { r.writeHead(200, { "content-type": "text/html" });
  r.end('<html><head><title>CHỈNAM — Bàn vận hành</title><script src="https://grok.com/grok-app-builder/extensions.js"></script></head></html>'); });
s.listen(0, "127.0.0.1", () => console.log(s.address().port)); setTimeout(() => s.close(), 60000);
JS
node "$W/srv.mjs" >"$W/port" & SRV=$!
for _ in $(seq 1 50); do [ -s "$W/port" ] && break; sleep 0.1; done
URL="http://127.0.0.1:$(cat "$W/port")/"
show() { local label="$1"; shift; local out rc; out="$(cd "$H" && bash -c "$*" 2>&1)"; rc=$?
  echo "=== $label"; echo "[${#out} byte] $(printf '%s' "$out" | head -2 | sed -E "s#$H#H#g; s/127\.0\.0\.1:[0-9]+/127.0.0.1:PORT/g" | tr '\n' ' ' | cut -c1-200)"; echo "EXIT=$rc"; }
show "node /dev/stdin < script (stdin là tệp)"            "node /dev/stdin '$URL' < $S"
show "cat script | node --input-type=module - (stdin là ống)" "cat $S | node --input-type=module - '$URL'"
show "node -e import(...) (nạp như module, không phải gọi script)" "node --input-type=module -e \"await import('./$S')\" '$URL'"
kill "$SRV" 2>/dev/null; wait 2>/dev/null; rm -rf "$W"
