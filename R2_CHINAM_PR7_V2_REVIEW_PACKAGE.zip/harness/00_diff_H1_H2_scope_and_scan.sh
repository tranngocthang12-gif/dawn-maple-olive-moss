#!/usr/bin/env bash
# R2 vòng 2 — việc 1: phạm vi diff H1 -> H2, tệp bảo vệ, thông điệp 4 commit mới, quét bí mật.
# Cách dùng: bash 00_diff_H1_H2_scope_and_scan.sh <git clone repo (đã fetch refs/pull/7/head -> origin/pr7)> <results/diff>
set -u
OUT="$(mkdir -p "$2" && cd "$2" && pwd -P)"; cd "$1"
M=609ed1bd7cdbea76842745985e34c13e91e050c4
H1=a1aa7005d27dc617566f8e94eaf13b9c227bba7b
H2=a867864073ca2fa11b725e53e088506da1584417
{
echo "### refs/pull/7/head = $(git rev-parse origin/pr7); origin/chinam/rel-02-settings-guard = $(git rev-parse origin/chinam/rel-02-settings-guard)"
echo "### H1 tổ tiên của H2? $(git merge-base --is-ancestor $H1 $H2 && echo YES || echo NO); số commit H1..H2 = $(git rev-list --count $H1..$H2)"
echo "### merge-base(M,H2) == M? $(test "$(git merge-base $M $H2)" = $M && echo YES || echo NO)"
echo "### Commit H1..H2"; git log --reverse --format='%H | parents=%P | author=%an <%ae> | committer=%cn <%ce> | %s' $H1..$H2
echo "### git diff --name-status H1 H2"; git diff --name-status $H1 $H2
echo "### git diff --stat H1 H2"; git diff --stat $H1 $H2
echo "### Tệp đổi theo từng commit"; for c in $(git rev-list --reverse $H1..$H2); do echo "-- $c $(git log -1 --format=%s $c)"; git diff-tree --no-commit-id --name-status -r $c; done
echo "### Tệp đổi trong vùng bảo vệ / phụ thuộc H1->H2 (kỳ vọng rỗng):"
git diff --name-only $H1 $H2 -- 'scripts/grok-pwa-*' server public/__grok src package.json package-lock.json vercel.json AGENTS.md AGENTS.project.md vite.config.ts tsconfig.json .github .grok startup.sh migrations
echo "(hết danh sách)"
echo "### Tương tự M->H2 (cả PR):"
git diff --name-only $M $H2 -- 'scripts/grok-pwa-*' server public/__grok src package.json package-lock.json vercel.json AGENTS.md vite.config.ts tsconfig.json
echo "(hết danh sách)"
echo "### blob hash ở M, H1, H2"; for f in package.json package-lock.json vercel.json AGENTS.md AGENTS.project.md .github/workflows/chinam-stage1-verification.yml; do echo "$f M=$(git rev-parse $M:$f) H1=$(git rev-parse $H1:$f) H2=$(git rev-parse $H2:$f)"; done
echo "### tree hash ở M, H1, H2"; for d in server public/__grok src .github; do echo "$d M=$(git rev-parse $M:$d) H1=$(git rev-parse $H1:$d) H2=$(git rev-parse $H2:$d)"; done
for f in $(git ls-tree --name-only $H2 scripts/ | grep 'grok-pwa-'); do echo "$f M=$(git rev-parse $M:$f) H1=$(git rev-parse $H1:$f) H2=$(git rev-parse $H2:$f)"; done
echo "### Import trong các tệp script đổi/thêm (H2):"
for f in $(git diff --name-only $H1 $H2 -- scripts); do echo "-- $f"; git show $H2:$f | grep -n -E '^\s*import|from "|require\(' ; done
} >"$OUT/01_diff_scope_H1_H2.txt" 2>&1
git log --reverse --format='=== %H%nAuthor: %an <%ae>%nCommitter: %cn <%ce>%n%n%B' $H1..$H2 >"$OUT/02_commit_messages_H1_H2.txt"
git log --reverse --format='=== %H%n%(trailers)' $H1..$H2 >"$OUT/02b_commit_trailers_H1_H2.txt"
git diff $H1 $H2 >"$OUT/03_full_diff_H1_to_H2.patch"
D="$OUT/03_full_diff_H1_to_H2.patch"; C="$OUT/02_commit_messages_H1_H2.txt"
B="$(mktemp)"; git log --reverse --format='%B' $H1..$H2 >"$B"   # chỉ THÂN thông điệp, không có dòng tác giả
{
echo "### Quét: (A) = dòng THÊM của diff H1->H2; (B) = chỉ thân thông điệp 4 commit; (C) = thân + tiêu đề tác giả"
echo "--- (B) liên kết phiên / claude.ai / Co-Authored-By / Claude-Session (kỳ vọng 0):"
grep -n -i -E 'claude\.ai|session_|Claude-Session|Co-Authored-By|https?://' "$B"; echo "(hết) số dòng=$(grep -c -i -E 'claude\.ai|session_|Claude-Session|Co-Authored-By|https?://' "$B")"
echo "--- (B) địa chỉ thư trong thân thông điệp (kỳ vọng 0):"; grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "$B" | sort | uniq -c; echo "(hết)"
echo "--- (C) địa chỉ thư kể cả trường Author/Committer:"; grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "$C" | sort | uniq -c; echo "(hết)"
echo "--- (A) địa chỉ thư:"; grep -E '^\+' "$D" | grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' | sort | uniq -c; echo "(hết)"
echo "--- (A) từ khoá nhạy cảm:"; grep -E '^\+' "$D" | grep -i -E 'password|passwd|secret|token|api[_-]?key|private key|BEGIN [A-Z ]*KEY|bearer|authorization|DATABASE_URL|XAI_API_KEY'; echo "(hết)"
echo "--- (A)+(B) mẫu khoá phổ biến:"; { grep -E '^\+' "$D"; cat "$B"; } | grep -E 'ghp_[A-Za-z0-9]{20,}|github_pat_|gho_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,}|xox[bp]-|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'; echo "(hết)"
echo "--- (A)+(B) mọi URL (đường dẫn trong repo này rút gọn):"; { grep -E '^\+' "$D"; cat "$B"; } | grep -o -E 'https?://[^ )>"`]+' | sed -E 's#(github.com/tranngocthang12-gif/dawn-maple-olive-moss)/.*#\1/…#' | sort | uniq -c; echo "(hết)"
echo "--- (A) github.com/<owner>/<repo> khác repo này:"; grep -E '^\+' "$D" | grep -o -E 'github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+' | grep -v 'tranngocthang12-gif/dawn-maple-olive-moss' | sort -u; echo "(hết)"
} >"$OUT/04_secret_scan_H1_H2.txt" 2>&1
rm -f "$B"
