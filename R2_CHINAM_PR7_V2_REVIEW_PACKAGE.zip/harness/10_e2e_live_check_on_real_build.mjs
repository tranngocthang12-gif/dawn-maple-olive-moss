#!/usr/bin/env node
// R2 vòng 2 — đầu-cuối: phục vụ HÀM MÁY CHỦ THẬT đã build (.vercel/output/functions/__server.func/index.mjs)
// qua HTTP cục bộ (mỗi giá trị VITE_GROK_EXTENSIONS một tiến trình riêng), rồi chạy đúng CLI
// `node scripts/check-live-no-grok-extension.mjs <url>` từ gốc checkout.
// Mục đích: (1) dấu hiệu <title> khớp đúng đầu ra thật (không ĐỎ SAI trên app thật);
//           (2) cùng bản build: =0 -> PASS, không đặt biến -> FAIL vì có script;
//           (3) mô tả thẻ <title> trong HTML thật (số lượng, vị trí, chuẩn hoá Unicode).
// Cách dùng: node 10_e2e_live_check_on_real_build.mjs <checkout> <.vercel/output>
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const H = resolve(process.argv[2] ?? ".");
const OUT = resolve(process.argv[3] ?? ".vercel/output");
const ENTRY = join(OUT, "functions/__server.func/index.mjs");
if (!existsSync(ENTRY)) { console.error("missing", ENTRY); process.exit(1); }
const SCRIPT = join(H, "scripts/check-live-no-grok-extension.mjs");
const MARK = "<title>CHỈNAM — Bàn vận hành</title>";

const SERVER = `
import { createServer } from "node:http";
const mod = await import(process.argv[1]);
const s = createServer(async (req, res) => {
  try {
    const headers = {};
    for (const k of ["accept", "accept-language", "user-agent"]) if (req.headers[k]) headers[k] = req.headers[k];
    const r = await mod.default.fetch(new Request("http://" + req.headers.host + req.url, { method: req.method, headers }));
    const body = Buffer.from(await r.arrayBuffer());
    const out = {};
    r.headers.forEach((v, k) => { if (k !== "content-length" && k !== "transfer-encoding") out[k] = v; });
    res.writeHead(r.status, out); res.end(body);
  } catch (e) { res.writeHead(599); res.end(String(e)); }
});
s.listen(0, "127.0.0.1", () => process.stdout.write("PORT " + s.address().port + "\\n"));
`;

function startServer(flag) {
  const env = { ...process.env };
  delete env.VITE_GROK_EXTENSIONS;
  if (flag !== undefined) env.VITE_GROK_EXTENSIONS = flag;
  const child = spawn(process.execPath, ["--input-type=module", "-e", SERVER, pathToFileURL(ENTRY).href], { env, stdio: ["ignore", "pipe", "pipe"] });
  return new Promise((ok, fail) => {
    let buf = "";
    child.stdout.on("data", (c) => { buf += c; const m = buf.match(/PORT (\d+)/); if (m) ok({ child, port: Number(m[1]) }); });
    child.stderr.on("data", (c) => process.stderr.write(c));
    setTimeout(() => fail(new Error("server did not start")), 60_000);
  });
}

function cli(url) {
  return new Promise((ok) => {
    const child = spawn(process.execPath, ["scripts/check-live-no-grok-extension.mjs", url], { cwd: H, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    child.stdout.on("data", (c) => (out += c)); child.stderr.on("data", (c) => (out += c));
    child.on("close", (code) => ok({ code, out: out.trim() }));
  });
}

for (const flag of ["0", undefined]) {
  const label = flag === undefined ? "UNSET" : JSON.stringify(flag);
  const { child, port } = await startServer(flag);
  const base = `http://127.0.0.1:${port}`;
  const res = await fetch(`${base}/`, { headers: { accept: "text/html" } });
  const body = await res.text();
  const titles = [...body.matchAll(/<title\b[^>]*>[\s\S]*?<\/title>/gi)].map((m) => ({ at: m.index, text: m[0] }));
  console.log(`--- VITE_GROK_EXTENSIONS=${label} (cùng một bản build)`);
  console.log(`raw GET / : status=${res.status} content-type=${res.headers.get("content-type")} chars=${body.length}`);
  console.log(`  số thẻ <title>=${titles.length}; các thẻ=${JSON.stringify(titles)}`);
  console.log(`  marker xuất hiện ${body.split(MARK).length - 1} lần; vị trí đầu=${body.indexOf(MARK)}; thẻ title đầu tiên là marker? ${titles[0]?.text === MARK}`);
  console.log(`  HTML ở dạng NFC? ${body === body.normalize("NFC")}; marker trong mã script ở dạng NFC? ${MARK === MARK.normalize("NFC")}`);
  console.log(`  needle grok-app-builder/extensions.js có trong HTML? ${body.includes("grok-app-builder/extensions.js")}`);
  for (const p of ["/", "/?utm=1", "/khong-ton-tai-r2"]) {
    const r = await cli(`${base}${p}`);
    console.log(`  CLI ${p.padEnd(18)} EXIT=${r.code} | ${r.out.replace(/127\.0\.0\.1:\d+/g, "127.0.0.1:PORT")}`);
  }
  child.kill();
}
