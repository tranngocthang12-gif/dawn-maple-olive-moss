#!/usr/bin/env bash
# R2 vòng 2 — việc 5: liên kết bình luận vòng 1 ghi trong REVIEW_LOG.md có thật trên PR #7 và mang đúng SHA-256 báo cáo không.
# API GitHub bị giới hạn lượt gọi trong sandbox (ghi lại phản hồi 403), nên đọc trang HTML công khai của PR #7.
# Cách dùng: bash 13_review_log_comment_check.sh <thư mục kết quả>
set -u
OUT="$(mkdir -p "$1" && cd "$1" && pwd -P)"
curl -s -D "$OUT/api_comment_6788374508_headers.txt" -o "$OUT/api_comment_6788374508_body.json" \
  https://api.github.com/repos/tranngocthang12-gif/dawn-maple-olive-moss/issues/comments/6788374508
curl -s -L -o /tmp/r2v2_pr7.html "https://github.com/tranngocthang12-gif/dawn-maple-olive-moss/pull/7"
python3 - <<'PY' | tee "$OUT/pr7_page_comment_check.txt"
import re, html
s = open('/tmp/r2v2_pr7.html', encoding='utf-8').read()
ids = [(m.start(), m.group(1)) for m in re.finditer(r'id="issuecomment-(\d+)"', s)]
print('các id bình luận trên trang PR #7 (thứ tự):', [x[1] for x in ids])
st = [p for p, i in ids if i == '6788374508'][0]; nxt = [p for p, i in ids if p > st and i != '6788374508']
txt = html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', s[st: nxt[0] if nxt else len(s)])))
print('độ dài văn bản bình luận 6788374508 (sau khi bỏ thẻ HTML):', len(txt))
for kw in ['060a84dd4bf71e9734bc12b065b64a18915ef35fe7d6e164c0b2576d0138e32e', 'a1aa7005d27dc617566f8e94eaf13b9c227bba7b', 'KẾT LUẬN: CHANGES REQUIRED', 'MIỄN TRỪ W-01', 'R2C7-01', 'R2C7-02', 'R2C7-03']:
    print(f'  "{kw[:40]}" xuất hiện {txt.count(kw)} lần')
k = txt.find('060a84dd'); print('  ngữ cảnh SHA-256:', txt[max(0, k-160):k+70])
print('  người đăng:', re.search(r'(\S+) commented', txt).group(1))
PY
