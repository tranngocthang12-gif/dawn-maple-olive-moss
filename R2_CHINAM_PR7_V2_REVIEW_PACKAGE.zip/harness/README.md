# Harness R2 vòng 2 — PR #7 CHỈNAM (tái hiện)

Mọi kết quả trong `../results/` sinh ra từ các tệp ở đây. Không tệp nào sửa mã được chấm; các phép thử
đột biến (06, 12) chỉ sửa **bản sao** trong thư mục tạm.

- `v1/` = harness của R2 vòng 1, chép **nguyên byte** từ gói `R2_CHINAM_PR7_REVIEW_PACKAGE.zip`
  (SHA-256 gói `7139800520c859db30e0ccf98d883d4542b3380c9c04f1e7eb5d119ae8c38a9e`; đối chiếu ở
  `results/01_round1_package_integrity.txt`). Hướng dẫn gốc: `v1/README_v1.md`.
- Các tệp ở thư mục này (00, 09–14) là phép thử mới của vòng 2.

Yêu cầu: Linux, bash, Node 22, npm, git, python3, openssl; mạng tới registry npm và github.com.

## Chuẩn bị (từ một thư mục trống)

```bash
git clone https://github.com/tranngocthang12-gif/dawn-maple-olive-moss.git repo
git -C repo fetch origin refs/pull/7/head:refs/remotes/origin/pr7
git -C repo worktree add --detach "$PWD/wt_h2" a867864073ca2fa11b725e53e088506da1584417
git -C repo worktree add --detach "$PWD/wt_h1" a1aa7005d27dc617566f8e94eaf13b9c227bba7b
mkdir certs && openssl req -x509 -newkey rsa:2048 -nodes -keyout certs/key.pem -out certs/cert.pem -days 2 \
  -subj "/CN=127.0.0.1" -addext "subjectAltName=IP:127.0.0.1,DNS:localhost"
```

## Thứ tự chạy

| Tệp | Việc | Kết quả |
| --- | --- | --- |
| `00_diff_H1_H2_scope_and_scan.sh repo results/diff` | Diff H1→H2, hash tệp bảo vệ, thông điệp 4 commit, quét bí mật | `results/diff/01–04_*` |
| `RUNNER_TEMP_OVERRIDE=/tmp/r2v2_runner_temp bash v1/01_pipeline_H.sh wt_h2 results/H2_pipeline` | npm ci, typecheck, lint, test, build, build sạch kiểu Vercel, script CI (workflow H2 = H1 theo blob) | `results/H2_pipeline/` |
| `node v1/03_probe_built_function_paths.mjs /tmp/r2v2_runner_temp/chinam-clean-vercel/.vercel/output` | Hàm máy chủ thật trên nhiều đường dẫn/giá trị biến | `results/probe/` |
| `node 10_e2e_live_check_on_real_build.mjs wt_h2 <.vercel/output>` | CLI live trên hàm máy chủ thật phục vụ qua HTTP: `=0` → PASS, không đặt → FAIL; mô tả thẻ title thật | `results/live_check/10_*` |
| `node v1/04_attack_live_check.mjs wt_h1` rồi `… wt_h2` | 43 phép thử vòng 1; H1 là đối chứng (~2 phút mỗi lần) | `results/live_check/04_*` |
| `node 09_attack_live_check_v2.mjs wt_h2 certs` | Phép thử thêm: dấu hiệu ngoài title, biến thể Unicode, nhiều title, trang nền tảng, chuyển hướng nhiều bước, origin khác cổng/giao thức | `results/live_check/09_*` |
| `bash v1/06_mutation_live_check_tests.sh wt_h2 /tmp/r2v2_mut` | Đột biến M0–M6 của vòng 1 (kiểm trước là chuỗi đích còn: `06_mutation_applicability_H2.txt`) | `results/live_check/06_*` |
| `bash 12_mutation_v2.sh wt_h2 /tmp/r2v2_mut12` | 19 đột biến mới (origin, content-type, thân rỗng, dấu hiệu, dòng PASS, guard realpath) | `results/live_check/12_*` |
| `bash v1/07_symlink_guard_live.sh wt_h2 /tmp/r2v2_sym_h2` | Guard khi gọi qua symlink (ca vòng 1) | `results/live_check/07_*` |
| `bash v1/02_failclosed_built_server_check.sh wt_h2 <.vercel/output> /tmp/r2v2_fc` | Bước CI fail-closed, gồm ca N qua symlink | `results/ci_step/02_*` |
| `bash 11_symlink_matrix_v2.sh wt_h1 …` rồi `… wt_h2 …` | 19 cách gọi × đỏ/xanh × 2 script; H1 là đối chứng | `results/live_check/11_*` |
| `bash 14_guard_exotic_invocations.sh wt_h2` (và `wt_h1`) | Cách gọi bất thường: `/dev/stdin`, ống stdin, `node -e import()` | `results/live_check/14_*` |
| `bash 13_review_log_comment_check.sh results/github_api` | Liên kết bình luận vòng 1 trong REVIEW_LOG có thật và mang đúng SHA-256 | `results/github_api/` |

`results/diff/05_ops_records_H2.txt` ghi các dòng REL-01/REL-02, OBS-01 và thứ tự REVIEW_LOG tại H2 (lệnh `grep`/`sed`
trong báo cáo, mục 6). `results/ci_step/02_diff_round1_vs_H2.txt` là `diff` giữa log 02 vòng 1 và H2 sau khi chuẩn hoá
đường dẫn tạm và thời gian.
