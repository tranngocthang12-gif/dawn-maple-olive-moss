#!/usr/bin/env bash
# R2 harness — chạy script kiểm hàm máy chủ của H lên đầu ra build sạch của M (609ed1b),
# để đối chiếu khẳng định trong PROJECT_STATE_V1.md (REL-02: "=0 -> ABSENT, unset -> PRESENT" trên 609ed1b).
# Cách dùng: bash 08_H_check_on_M_build.sh <checkout H> <.vercel/output của build sạch M>
set -u
node "$1/scripts/check-built-server-grok-extension.mjs" "$2"; echo "EXIT=$?"
