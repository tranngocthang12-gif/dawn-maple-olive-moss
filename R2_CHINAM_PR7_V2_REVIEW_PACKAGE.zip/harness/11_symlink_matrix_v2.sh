#!/usr/bin/env bash
# R2 vòng 2 — R2C7-02: gọi HAI script mới bằng nhiều kiểu đường dẫn, mỗi kiểu với một đầu vào ĐỎ và một đầu vào XANH.
# Bất biến cần giữ: thoát 0  =>  đầu ra có dòng PASS của phép kiểm
#   live : dòng bắt đầu bằng "PASS: " (cột FINAL_URL ghi riêng việc dòng đó có dạng "requested ... -> final ..." của H2)
#   built: dòng "BUILT_SERVER_GROK_EXTENSION_CHECK: PASS"
# Vi phạm in "!! THOÁT 0 KHÔNG KIỂM". Đầu vào ĐỎ phải thoát 1 với dòng FAIL.
# Thoát khác 0 do lỗi nạp module (ERR_MODULE_NOT_FOUND…) ghi "(đỏ do lỗi nạp, an toàn)": không kiểm được nhưng không xanh.
# Chạy trên H1 làm đối chứng (phải lộ vi phạm ở các kiểu qua symlink) và trên H2.
# Cách dùng: bash 11_symlink_matrix_v2.sh <checkout> <thư mục làm việc>
set -u
H="$(cd "$1" && pwd -P)"; W="$2"
rm -rf "$W" && mkdir -p "$W" && W="$(cd "$W" && pwd -P)"
NEEDLE='https://grok.com/grok-app-builder/extensions.js'
MARK='<title>CHỈNAM — Bàn vận hành</title>'

# máy chủ giả cho script live
cat >"$W/srv.mjs" <<EOF
import { createServer } from "node:http";
const page = (h) => '<!doctype html><html><head>$MARK' + h + '</head><body>app</body></html>';
const s = createServer((q, r) => { r.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  r.end(q.url === "/red" ? page('<script src="$NEEDLE" defer></script>') : page("")); });
s.listen(0, "127.0.0.1", () => console.log(s.address().port));
setTimeout(() => s.close(), 600000);
EOF
node "$W/srv.mjs" >"$W/port" & SRV=$!
for _ in $(seq 1 100); do [ -s "$W/port" ] && break; sleep 0.1; done
URL="http://127.0.0.1:$(cat "$W/port")"

# đầu ra build giả cho script CI
mkdir -p "$W/out_empty" "$W/out_good/functions/__server.func"
cat >"$W/out_good/functions/__server.func/index.mjs" <<EOF
export default { fetch: () => new Response(process.env.VITE_GROK_EXTENSIONS === "0" ? "<html><head></head><body>app</body></html>"
  : '<html><head><script src="$NEEDLE" defer></script></head><body>app</body></html>', { status: 200, headers: { "content-type": "text/html" } }) };
EOF

# các kiểu đường dẫn
L=live; B=built
SL=check-live-no-grok-extension.mjs; SB=check-built-server-grok-extension.mjs
ln -s "$H/scripts/$SL" "$W/f_link_live.mjs";            ln -s "$H/scripts/$SB" "$W/f_link_built.mjs"
ln -s "$(realpath --relative-to="$W" "$H/scripts/$SL")" "$W/f_rel_link_live.mjs"
ln -s "$(realpath --relative-to="$W" "$H/scripts/$SB")" "$W/f_rel_link_built.mjs"
ln -s "$H/scripts" "$W/d_link"
ln -s "$H" "$W/repo_link"
ln -s "$W/f_link_live.mjs" "$W/c2_live.mjs";  ln -s "$W/c2_live.mjs" "$W/c1_live.mjs"      # chuỗi tệp 2 bước
ln -s "$W/f_link_built.mjs" "$W/c2_built.mjs"; ln -s "$W/c2_built.mjs" "$W/c1_built.mjs"
ln -s "$W/d_link" "$W/dB"; ln -s "$W/dB" "$W/dA"                                         # chuỗi thư mục 2 bước
ln -s "$W/repo_link" "$W/mix"                                                            # chuỗi thư mục tới gốc repo
ln -s "$H/scripts/$SL" "$W/checklive_noext";   ln -s "$H/scripts/$SB" "$W/checkbuilt_noext"   # symlink không đuôi
SP="$W/thư mục có dấu cách %20 #x"; mkdir -p "$SP"; cp -r "$H/scripts" "$SP/scripts"; ln -s "$SP/scripts" "$W/sp_link"
mkdir -p "$W/hard"; cp -al "$H/scripts" "$W/hard/scripts"                                # bản sao bằng hard link

run() { # $1 nhãn, $2 script(live|built), $3 cwd, rest = lệnh node (đã gồm đường dẫn script)
  local label="$1" kind="$2" cwd="$3"; shift 3
  for io in red green; do
    local arg
    if [ "$kind" = live ]; then arg="$URL/$io"; else [ $io = red ] && arg="$W/out_empty" || arg="$W/out_good"; fi
    local out rc
    out="$(cd "$cwd" && "$@" "$arg" 2>&1)"; rc=$?
    local pass=no fail=no final=- crash=no
    printf '%s\n' "$out" | grep -q -E 'ERR_MODULE_NOT_FOUND|^Error|Error \[' && crash=yes
    if [ "$kind" = live ]; then
      printf '%s\n' "$out" | grep -q -E '^PASS: ' && pass=yes
      printf '%s\n' "$out" | grep -q -E '^FAIL: ' && fail=yes
      if [ $pass = yes ]; then printf '%s\n' "$out" | grep -q -E '^PASS: requested .* -> final .* -> ' && final=yes || final=no; fi
    else
      printf '%s\n' "$out" | grep -q -E '^BUILT_SERVER_GROK_EXTENSION_CHECK: PASS$' && pass=yes
      printf '%s\n' "$out" | grep -q -E '^FAIL: ' && fail=yes
    fi
    local verdict="ok"
    if [ $rc -eq 0 ] && [ $pass = no ]; then verdict="!! THOÁT 0 KHÔNG KIỂM"
    elif [ $rc -ne 0 ] && [ $crash = yes ]; then verdict="(đỏ do lỗi nạp, an toàn)"
    elif [ $io = red ] && [ $rc -ne 1 -o $fail = no ]; then verdict="!! ĐỎ KHÔNG ĐÚNG"
    elif [ $io = green ] && [ $rc -ne 0 ]; then verdict="!! XANH BỊ ĐỎ"; fi
    printf '%-24s | %-5s | %-56s | %-5s | EXIT=%s PASS_LINE=%s FINAL_URL=%s FAIL_LINE=%s CRASH=%s | bytes=%s\n' "$verdict" "$kind" "$label" "$io" "$rc" "$pass" "$final" "$fail" "$crash" "${#out}"
  done
}

for k in live built; do
  if [ $k = live ]; then S=$SL; else S=$SB; fi
  run "V01 tuyệt đối, đường dẫn thật"                         $k /      node "$H/scripts/$S"
  run "V02 tương đối từ gốc repo (cách sổ vận hành ghi)"      $k "$H"   node "scripts/$S"
  run "V03 tương đối có ./ và .."                             $k "$H/scripts" node "../scripts/./$S"
  run "V04 symlink tệp, tuyệt đối"                            $k /      node "$W/f_link_$k.mjs"
  run "V05 symlink tệp, đích tương đối"                       $k /      node "$W/f_rel_link_$k.mjs"
  run "V06 symlink thư mục scripts/, tuyệt đối"               $k /      node "$W/d_link/$S"
  run "V07 cd vào symlink gốc repo, tương đối"                $k "$W/repo_link" node "scripts/$S"
  run "V08 tương đối qua symlink thư mục (cwd=W)"             $k "$W"   node "d_link/$S"
  run "V09 chuỗi symlink tệp 2 bước"                          $k /      node "$W/c1_$k.mjs"
  run "V10 chuỗi symlink thư mục 2 bước"                      $k /      node "$W/dA/$S"
  run "V11 chuỗi thư mục tới gốc repo"                        $k /      node "$W/mix/scripts/$S"
  if [ $k = live ]; then NOEXT=checklive_noext; else NOEXT=checkbuilt_noext; fi
  run "V12 symlink tệp không có đuôi .mjs"                    $k /      node "$W/$NOEXT"
  run "V13 --preserve-symlinks-main + symlink tệp"            $k /      node --preserve-symlinks-main "$W/f_link_$k.mjs"
  run "V14 --preserve-symlinks(-main) + symlink thư mục"      $k /      node --preserve-symlinks --preserve-symlinks-main "$W/d_link/$S"
  run "V15 thư mục có dấu cách, dấu, %20, #"                  $k /      node "$SP/scripts/$S"
  run "V16 symlink tới thư mục có ký tự đặc biệt"             $k /      node "$W/sp_link/$S"
  run "V17 bản sao hard link"                                 $k /      node "$W/hard/scripts/$S"
  run "V18 /proc/self/cwd (symlink ma thuật) từ gốc repo"     $k "$H"   node "/proc/self/cwd/scripts/$S"
  run "V19 dấu // thừa trong đường dẫn"                       $k /      node "$H//scripts//$S"
done
kill "$SRV" 2>/dev/null; wait 2>/dev/null
