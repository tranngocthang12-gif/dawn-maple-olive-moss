#!/usr/bin/env bash
# R2 harness — PR #7 (CHỈNAM). Chạy pipeline trên đầu PR (H) đúng như workflow CI,
# ghi log nguyên văn vào results/. Không sửa mã nguồn được chấm.
#
# Cách dùng: bash 01_pipeline_H.sh <thư mục checkout git của H> <thư mục results>
# Yêu cầu: Node 22, npm, git, mạng tới registry npm.
set -u
SRC="$(cd "$1" && pwd -P)"
OUT="$(mkdir -p "$2" && cd "$2" && pwd -P)"
cd "$SRC"

run() {
  local name="$1"; shift
  echo "### $name" | tee "$OUT/$name.log"
  echo "\$ $*" | tee -a "$OUT/$name.log"
  local start end rc
  start=$(date +%s)
  bash -c "$*" >>"$OUT/$name.log" 2>&1
  rc=$?
  end=$(date +%s)
  echo "EXIT=$rc DURATION_S=$((end-start))" | tee -a "$OUT/$name.log"
  echo "$name EXIT=$rc" >>"$OUT/00_summary.txt"
  return 0
}

: >"$OUT/00_summary.txt"
echo "HEAD=$(git rev-parse HEAD)" | tee -a "$OUT/00_summary.txt"
echo "NODE=$(node --version) NPM=$(npm --version 2>/dev/null)" | tee -a "$OUT/00_summary.txt"

run 10_npm_ci        "npm ci --ignore-scripts --no-audit --no-fund"
run 11_typecheck     "npm run typecheck"
run 12_lint          "npm run lint"
run 13_test          "npm test"
run 14_vite_build_smoke "VITE_GROK_EXTENSIONS=0 PATH=./node_modules/.bin:\$PATH node scripts/with-app-env.mjs vite build"
run 15_npm_run_build "VITE_GROK_EXTENSIONS=0 npm run build"

# Build kiểu Vercel trên bản sạch — chép đúng thân bước CI (dòng 56–79 của workflow tại H),
# chỉ thay \$RUNNER_TEMP bằng thư mục tạm cục bộ.
export RUNNER_TEMP="${RUNNER_TEMP_OVERRIDE:-/tmp/r2_runner_temp}"
mkdir -p "$RUNNER_TEMP"
run 16_clean_vercel_build "$(cat <<'EOS'
set -e
CI=1
export CI
CLEAN_DIR="$RUNNER_TEMP/chinam-clean-vercel"
rm -rf "$CLEAN_DIR" && mkdir -p "$CLEAN_DIR"
git archive HEAD | tar -x -C "$CLEAN_DIR"
cd "$CLEAN_DIR"
test ! -e .vercel/output || { echo "FAIL: stale prebuilt output in clean archive"; exit 1; }
echo "CLEAN_VERCEL_BUILD: START"
npm install --omit=dev --no-audit --no-fund
VITE_GROK_EXTENSIONS=0 npm run build
test -d .vercel/output/static || { echo "FAIL: missing .vercel/output/static"; exit 1; }
if grep -R -F -q 'grok-app-builder/extensions.js' .vercel/output/static; then
  echo "FAIL: legacy Grok extension remains in generated static output"; exit 1
fi
if ! grep -R -F -q 'chinam-foundation-v2' .vercel/output; then
  echo "FAIL: generated Vercel output has no chinam-foundation-v2 marker"; exit 1
fi
echo "CLEAN_VERCEL_BUILD: PASS"
echo "GROK_EXTENSION_IN_STATIC: ABSENT"
echo "CHINAM_FOUNDATION_V2_IN_OUTPUT: PRESENT"
EOS
)"
run 17_check_built_server "node scripts/check-built-server-grok-extension.mjs \"$RUNNER_TEMP/chinam-clean-vercel/.vercel/output\""
cat "$OUT/00_summary.txt"
