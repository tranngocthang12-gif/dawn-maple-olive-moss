#!/usr/bin/env bash
# R2 vòng 2 — đột biến bổ sung cho các nhánh mới ở H2 (không có trong harness 06 vòng 1).
# Chép scripts/, package.json, src/routes/index.tsx của checkout sang thư mục tạm, sửa BẢN SAO, chạy các tệp test.
# "CAUGHT" = test đỏ khi có đột biến; "SURVIVED" = test vẫn xanh.
# Cách dùng: bash 12_mutation_v2.sh <checkout H2> <thư mục làm việc>
set -u
H="$(cd "$1" && pwd -P)"; WORK="$2"
rm -rf "$WORK" && mkdir -p "$WORK"
TL=scripts/check-live-no-grok-extension.test.mjs; TM=scripts/check-live-marker.test.mjs; TB=scripts/check-built-server-grok-extension.test.mjs
mutate() { # $1 nhãn, $2 tệp bị sửa (tương đối), $3 biểu thức python trên s, rest = các tệp test
  local label="$1" file="$2" expr="$3"; shift 3
  local d="$WORK/$label"; mkdir -p "$d/src/routes"; cp -r "$H/scripts" "$d/"; cp "$H/package.json" "$d/"; cp "$H/src/routes/index.tsx" "$d/src/routes/"
  if ! python3 - "$d/$file" "$expr" <<'EOF'
import sys
p, expr = sys.argv[1], sys.argv[2]
s = open(p, encoding="utf-8").read(); n = eval(expr)
if n == s: sys.exit(3)
open(p, "w", encoding="utf-8").write(n)
EOF
  then printf '%-46s NOT_APPLIED\n' "$label"; return; fi
  local out rc
  out="$(cd "$d" && timeout 180 node --test "$@" 2>&1)"; rc=$?
  printf '%-46s %s (exit=%s; %s)\n' "$label" "$([ $rc -ne 0 ] && echo CAUGHT || echo SURVIVED)" "$rc" "$(printf '%s' "$out" | grep -E '^# (pass|fail)' | tr '\n' ' ')"
}
LIVE=scripts/check-live-no-grok-extension.mjs; GUARD=scripts/is-main-module.mjs; BUILT=scripts/check-built-server-grok-extension.mjs
mutate N0_baseline_noop_all_tests        $LIVE  's + "\n// r2 no-op\n"'                                     $TL $TM $TB
mutate L1_drop_origin_check              $LIVE  's.replace("if (new URL(finalUrl).origin !== target.origin) {", "if (false) {")'   $TL $TM
mutate L2_drop_content_type_check        $LIVE  's.replace("if (mimeType !== \"text/html\") {", "if (false) {")'                   $TL $TM
mutate L3_drop_empty_body_check          $LIVE  's.replace("if (html.length === 0) return fail(\"empty body\");", "")'           $TL $TM
mutate L4_drop_marker_check              $LIVE  's.replace("if (!html.includes(CHINAM_APP_MARKER)) {", "if (false) {")'           $TL $TM
mutate L5_pass_line_without_final_url    $LIVE  's.replace("-> final ${result.finalUrl || \"(none)\"} ", "")'                    $TL $TM
mutate L6_marker_weakened_to_CHINAM      $LIVE  's.replace("export const CHINAM_APP_MARKER = \"<title>CHỈNAM — Bàn vận hành</title>\";", "export const CHINAM_APP_MARKER = \"CHỈNAM\";")' $TL $TM
mutate L7_drop_missing_final_url_check   $LIVE  's.replace("if (!finalUrl) return fail(\"response did not report a final URL\");", "")' $TL $TM
mutate L8_default_timeout_effectively_off $LIVE 's.replace("timeoutMs = 20_000", "timeoutMs = 2_147_483_647")'                 $TL $TM
mutate L9_mime_prefix_match_text_htmlx   $LIVE  's.replace("if (mimeType !== \"text/html\") {", "if (!mimeType.startsWith(\"text/htm\")) {")' $TL $TM
mutate G1_guard_no_realpath_either_side  $GUARD 's.replace("const self = realpathSync(fileURLToPath(metaUrl));\n    const entry = realpathSync(argv1);", "const self = fileURLToPath(metaUrl);\n    const entry = argv1;")' $TL $TB
mutate G2_guard_always_true              $GUARD 's.replace("  if (!argv1) return false;", "  return true;")'           $TL $TB
mutate G3_guard_always_false             $GUARD 's.replace("  if (!argv1) return false;", "  return false;")'          $TL $TB
mutate G4_guard_entry_not_realpathed     $GUARD 's.replace("const entry = realpathSync(argv1);", "const entry = argv1;")' $TL $TB
mutate G5_guard_self_not_realpathed      $GUARD 's.replace("const self = realpathSync(fileURLToPath(metaUrl));", "const self = fileURLToPath(metaUrl);")' $TL $TB
mutate G6_guard_catch_returns_true       $GUARD 's.replace("  } catch {\n    return false;", "  } catch {\n    return true;")' $TL $TB
mutate B1_built_old_string_guard         $BUILT 's.replace("if (isMainModule(import.meta.url)) main();", "if (import.meta.url === pathToFileURL(process.argv[1] ?? \"\").href) main();")' $TB
mutate B2_live_old_string_guard          $LIVE  's.replace("if (isMainModule(import.meta.url)) await main();", "if (import.meta.url === (await import(\"node:url\")).pathToFileURL(process.argv[1] ?? \"\").href) await main();")' $TL
mutate R1_route_title_changed            src/routes/index.tsx 's.replace("title: \"CHỈNAM — Bàn vận hành\"", "title: \"CHỈNAM — Bàn điều hành\"")' $TM
