# Harness R2 — PR #7 CHỈNAM (tái hiện)

Mọi kết quả trong `../results/` sinh ra từ các tệp ở đây. Không tệp nào sửa mã được chấm;
phép thử đột biến (06) chỉ sửa **bản sao** trong thư mục tạm.

Yêu cầu: Linux, bash, Node 22, npm, git, python3 (+ PyYAML cho 05), mạng tới registry npm và github.com.

## Chuẩn bị (từ một thư mục trống)

```bash
git clone https://github.com/tranngocthang12-gif/dawn-maple-olive-moss.git repo
git -C repo fetch origin refs/pull/7/head:refs/remotes/origin/pr7
git -C repo worktree add --detach "$PWD/wt_h" a1aa7005d27dc617566f8e94eaf13b9c227bba7b
git -C repo worktree add --detach "$PWD/wt_m" 609ed1bd7cdbea76842745985e34c13e91e050c4
# Đối chiếu với ZIP: `git archive <sha> | tar -x` phải trùng nội dung ZIP (results/00_environment.txt).
```

## Thứ tự chạy

| Tệp | Việc | Kết quả |
| --- | --- | --- |
| `00_diff_scope_and_secret_scan.sh repo results/diff` | Phạm vi diff, hash tệp bảo vệ, thông điệp commit, quét bí mật | `results/diff/` |
| `01_pipeline_H.sh wt_h results/H_pipeline` | npm ci, typecheck, lint, test, build, build sạch kiểu Vercel (thân bước CI), script kiểm hàm máy chủ | `results/H_pipeline/` |
| `RUNNER_TEMP_OVERRIDE=/tmp/r2_runner_temp_M 01_pipeline_H.sh wt_m results/M_baseline_pipeline` | Đối chứng trên M (bước 17 EXIT=1 là đúng: M chưa có script) | `results/M_baseline_pipeline/` |
| `08_H_check_on_M_build.sh wt_h /tmp/r2_runner_temp_M/chinam-clean-vercel/.vercel/output` | Script của H trên build sạch của 609ed1b | `results/M_baseline_pipeline/18_*.log` |
| `02_failclosed_built_server_check.sh wt_h /tmp/r2_runner_temp/chinam-clean-vercel/.vercel/output /tmp/r2_fc` | Bước CI mới có fail-closed không (13 ca hỏng + 1 ca thật + symlink) | `results/ci_step/02_*.log` |
| `05_ci_clean_dir_equivalence.sh repo /tmp/r2_eq` | Đổi mktemp → `$RUNNER_TEMP` có làm yếu phép kiểm cũ không | `results/ci_step/05_*.log` |
| `node 03_probe_built_function_paths.mjs /tmp/r2_runner_temp/chinam-clean-vercel/.vercel/output` | Hàm máy chủ trên nhiều đường dẫn và nhiều giá trị biến | `results/probe/` |
| `node 04_attack_live_check.mjs wt_h` | 43 phép thử phá script kiểm bản chạy thật (mất ~2 phút vì 3 ca treo × 20 s) | `results/live_check/04_*.log` |
| `07_symlink_guard_live.sh wt_h /tmp/r2_sym2` | Guard `import.meta.url` khi gọi qua symlink | `results/live_check/05_*.log` |
| `06_mutation_live_check_tests.sh wt_h /tmp/r2_mut` | Test đơn vị có bắt được đột biến không | `results/live_check/06_*.log` |

`results/github_api/` ghi lần thử đọc API GitHub (bị giới hạn lượt gọi) và kiểm SHA của PR #6 bằng git.
