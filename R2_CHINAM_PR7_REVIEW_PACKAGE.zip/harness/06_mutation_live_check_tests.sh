#!/usr/bin/env bash
# R2 harness — test đơn vị scripts/check-live-no-grok-extension.test.mjs có bắt được các đột biến không?
# Chép scripts/ của H sang thư mục tạm, sửa bản sao (KHÔNG sửa H), chạy riêng tệp test.
# "CAUGHT" = test đỏ khi có đột biến (tốt); "SURVIVED" = test vẫn xanh (độ phủ thiếu).
# Cách dùng: bash 06_mutation_live_check_tests.sh <checkout H> <thư mục làm việc>
set -u
H="$(cd "$1" && pwd -P)"; WORK="$2"
rm -rf "$WORK" && mkdir -p "$WORK"
mutate() { # $1 = nhãn, $2 = biểu thức python thay chuỗi trên mã nguồn s
  local d="$WORK/$1"; mkdir -p "$d"; cp -r "$H/scripts" "$d/"; cp "$H/package.json" "$d/"
  python3 - "$d/scripts/check-live-no-grok-extension.mjs" "$2" <<'EOF'
import sys
p, expr = sys.argv[1], sys.argv[2]
s = open(p).read(); n = eval(expr)
assert n != s, "mutation did not apply"
open(p, "w").write(n)
EOF
  local out rc
  out="$(cd "$d" && timeout 120 node --test scripts/check-live-no-grok-extension.test.mjs 2>&1)"; rc=$?
  printf '%-44s %s (exit=%s; %s)\n' "$1" "$([ $rc -ne 0 ] && echo CAUGHT || echo SURVIVED)" "$rc" "$(printf '%s' "$out" | grep -E '^# (pass|fail)' | tr '\n' ' ')"
}
mutate M0_baseline_noop                  's + "\n// r2 no-op\n"'
mutate M1_drop_timeout                   's.replace("      signal: AbortSignal.timeout(timeoutMs),\n", "")'
mutate M2_drop_status_check              's.replace("response.status < 200 || response.status > 299", "false")'
mutate M3_drop_needle_check              's.replace("if (html.includes(GROK_EXTENSION_NEEDLE))", "if (false)")'
mutate M4_redirect_manual_no_follow      's.replace("redirect: \"follow\"", "redirect: \"manual\"")'
mutate M5_case_insensitive_needle        's.replace("html.includes(GROK_EXTENSION_NEEDLE)", "html.toLowerCase().includes(GROK_EXTENSION_NEEDLE)")'
mutate M6_allow_any_protocol             's.replace("target.protocol !== \"https:\" && target.protocol !== \"http:\"", "false")'
