#!/usr/bin/env bash
# R2 harness — việc 1 và 6: phạm vi diff M -> H, thông điệp commit, quét bí mật.
# Cách dùng: bash 00_diff_scope_and_secret_scan.sh <git clone repo (đã fetch refs/pull/7/head -> origin/pr7)> <results/diff>
set -u
cd "$1"; OUT="$(mkdir -p "$2" && cd "$2" && pwd -P)"
M=609ed1bd7cdbea76842745985e34c13e91e050c4; H=a1aa7005d27dc617566f8e94eaf13b9c227bba7b
{
echo "### git diff --name-status M H"; git diff --name-status $M $H
echo "### git diff --stat M H"; git diff --stat $M $H
echo "### Tệp đổi trong vùng bảo vệ / phụ thuộc (kỳ vọng rỗng):"
git diff --name-only $M $H -- 'scripts/grok-pwa-*' server public/__grok src package.json package-lock.json vercel.json AGENTS.md vite.config.ts tsconfig.json .grok startup.sh migrations
echo "(hết danh sách)"
echo "### Số tệp đổi trong scripts/grok-pwa-*, server/, public/__grok/, src/, package*.json: $(git diff --name-only $M $H -- 'scripts/grok-pwa-*' server public/__grok src package.json package-lock.json | wc -l)"
echo "### blob hash ở M và H"; for f in package.json package-lock.json vercel.json AGENTS.md; do echo "$f M=$(git rev-parse $M:$f) H=$(git rev-parse $H:$f)"; done
echo "### tree hash ở M và H"; for d in server public/__grok src; do echo "$d M=$(git rev-parse $M:$d) H=$(git rev-parse $H:$d)"; done
for f in $(git ls-tree --name-only $H scripts/ | grep 'grok-pwa-'); do echo "$f M=$(git rev-parse $M:$f) H=$(git rev-parse $H:$f)"; done
echo "### Commit trong PR (M..H)"; git log --format='%H | parents=%P | author=%an <%ae> | committer=%cn <%ce> | %s' $M..$H
echo "### Tệp đổi theo từng commit"; for c in $(git rev-list --reverse $M..$H); do echo "-- $c"; git diff-tree --no-commit-id --name-status -r $c; done
echo "### merge-base(M,H) == M? $(test "$(git merge-base $M $H)" = $M && echo YES || echo NO)"
echo "### origin/chinam/rel-02-settings-guard = $(git rev-parse origin/chinam/rel-02-settings-guard); refs/pull/7/head = $(git rev-parse origin/pr7)"
} >"$OUT/01_diff_scope.txt" 2>&1
git log --format='=== %H%nAuthor: %an <%ae>%nCommitter: %cn <%ce>%n%n%B' $M..$H >"$OUT/02_commit_messages_PR7.txt"
git diff $M $H >"$OUT/03_full_diff_M_to_H.patch"
D="$OUT/03_full_diff_M_to_H.patch"; C="$OUT/02_commit_messages_PR7.txt"
{
echo "### Quét bí mật: (A) = dòng THÊM của diff; (C) = thông điệp + tiêu đề tác giả của 3 commit PR"
echo "--- (A) email:";  grep -E '^\+' "$D" | grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' | sort | uniq -c; echo "(hết)"
echo "--- (C) email:";  grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "$C" | sort | uniq -c; echo "(hết)"
echo "--- (A) từ khoá nhạy cảm:"; grep -E '^\+' "$D" | grep -i -E 'password|passwd|secret|token|api[_-]?key|private key|BEGIN [A-Z ]*KEY|bearer|authorization|DATABASE_URL|XAI_API_KEY'; echo "(hết)"
echo "--- (C) từ khoá nhạy cảm:"; grep -i -E 'password|passwd|secret|token|api[_-]?key|private key|bearer' "$C"; echo "(hết)"
echo "--- (A)+(C) mẫu khoá phổ biến:"; { grep -E '^\+' "$D"; cat "$C"; } | grep -E 'ghp_[A-Za-z0-9]{20,}|github_pat_|gho_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,}|xox[bp]-|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'; echo "(hết)"
echo "--- (A)+(C) chuỗi dài >=24 ký tự [A-Za-z0-9_-] (trừ SHA hex 40):"; { grep -E '^\+' "$D"; cat "$C"; } | grep -o -E '[A-Za-z0-9_-]{24,}' | grep -v -E '^[0-9a-f]{40}$' | sort -u; echo "(hết)"
echo "--- (A)+(C) mọi URL (đường dẫn trong repo này rút gọn):"; { grep -E '^\+' "$D"; cat "$C"; } | grep -o -E 'https?://[^ )>"`]+' | sed -E 's#(github.com/tranngocthang12-gif/dawn-maple-olive-moss)/.*#\1/…#; s#(claude.ai/code/session_).*#\1…#' | sort | uniq -c
echo "--- (A) github.com/<owner>/<repo> khác repo này:"; grep -E '^\+' "$D" | grep -o -E 'github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+' | grep -v 'tranngocthang12-gif/dawn-maple-olive-moss' | sort -u; echo "(hết)"
echo "--- Số dòng nhắc tên 'TRUNG TÂM TÀI CHÍNH' theo tệp, ở M và ở H (chỉ tên; không URL):"
for r in $M $H; do echo "$r:"; for f in AGENTS.project.md PROJECT_STATE_V1.md TASK_QUEUE_V1.md REVIEW_LOG.md; do echo "  $f $(git show $r:$f | grep -c 'TRUNG TÂM TÀI CHÍNH')"; done; done
} >"$OUT/04_secret_scan.txt" 2>&1
