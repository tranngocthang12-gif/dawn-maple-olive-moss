#!/usr/bin/env node
// R2 vòng 2 — phép thử thêm cho scripts/check-live-no-grok-extension.mjs (R2C7-01).
// Phần CLI: chạy đúng lệnh Owner sẽ chạy (node <script> <url>), cwd = gốc checkout.
// Phần FN : gọi hàm checkLiveNoGrokExtension đã export với fetchImpl giả, chỉ cho các ca
//           không dựng được bằng máy chủ thật (origin chỉ khác giao thức, cổng mặc định).
// "should": RED / GREEN = kết quả an toàn mong đợi; "RED~" = đỏ là an toàn nhưng là ĐỎ SAI nếu app thật
// trả đúng dạng đó (harness 10 kiểm app thật); "?" = không có kỳ vọng cứng, chỉ ghi nhận.
// Dòng "!! XANH SAI" = exit 0 trong khi should = RED.
//
// Cách dùng: node 09_attack_live_check_v2.mjs <checkout> [<thư mục chứng chỉ có cert.pem, key.pem>]
import { spawn } from "node:child_process";
import { readFileSync, existsSync } from "node:fs";
import { createServer } from "node:http";
import { createServer as createHttpsServer } from "node:https";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";

const H = resolve(process.argv[2] ?? ".");
const CERTS = process.argv[3] ? resolve(process.argv[3]) : null;
const SCRIPT = `${H}/scripts/check-live-no-grok-extension.mjs`;
const SRC = "https://grok.com/grok-app-builder/extensions.js";
const MARK = "<title>CHỈNAM — Bàn vận hành</title>";
const page = (head, body = "app") => `<!doctype html><html lang="vi"><head>${head}</head><body>${body}</body></html>`;
const APP = (extra = "") => page(MARK + extra);
const html = (body, status = 200) => ({ status, headers: { "content-type": "text/html; charset=utf-8" }, body });

function serve(routes, host = "127.0.0.1") {
  const s = createServer((req, res) => {
    const u = new URL(req.url, "http://x");
    let r = routes[u.pathname];
    if (typeof r === "function") r = r(u);
    if (!r) { res.writeHead(404, { "content-type": "text/html" }); res.end("nf"); return; }
    res.writeHead(r.status, r.headers);
    res.end(r.body);
  });
  return new Promise((ok) => s.listen(0, host, () => ok(s)));
}
const redirect = (location, status = 302) => ({ status, headers: { location }, body: "" });

// ---- máy chủ phụ: B = cùng host 127.0.0.1, khác cổng; C = host "localhost" (khác host)
const B = await serve({ "/clean": html(APP()) });
const BASE_B = `http://127.0.0.1:${B.address().port}`;
const C = await serve({ "/clean": html(APP()), "/back": (u) => redirect(`${u.searchParams.get("to")}`) });
const BASE_C = `http://localhost:${C.address().port}`;

// ---- máy chủ HTTPS (khác giao thức + khác cổng), chứng chỉ tự ký, CLI tin qua NODE_EXTRA_CA_CERTS
let D = null, BASE_D = null;
if (CERTS && existsSync(join(CERTS, "cert.pem"))) {
  D = createHttpsServer({ cert: readFileSync(join(CERTS, "cert.pem")), key: readFileSync(join(CERTS, "key.pem")) }, (req, res) => {
    const u = new URL(req.url, "https://x");
    if (u.pathname === "/to-http") { res.writeHead(302, { location: u.searchParams.get("to") }); res.end(); return; }
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(APP());
  });
  await new Promise((ok) => D.listen(0, "127.0.0.1", ok));
  BASE_D = `https://127.0.0.1:${D.address().port}`;
}

// ---- máy chủ chính A
let A;
const ROUTES = {
  // Dấu hiệu nằm ngoài thẻ <title> thật (title thật là trang khác)
  "/marker-in-comment": html(page(`<title>Trang khác</title><!-- ${MARK} -->`)),
  "/marker-in-script-string": html(page(`<title>Trang khác</title><script>var t = "${MARK}";</script>`)),
  "/marker-in-attribute": html(page(`<title>Trang khác</title><meta name="x" content="${MARK}">`)),
  "/marker-in-template": html(page(`<title>Trang khác</title><template>${MARK}</template>`)),
  "/marker-in-body-no-head-title": html(page(``, `Trang khác ${MARK}`)),
  "/marker-html-escaped-in-body": html(page(`<title>Trang khác</title>`, `&lt;title&gt;CHỈNAM — Bàn vận hành&lt;/title&gt;`)),
  // Title khớp một phần / khác dạng
  "/title-partial-CHINAM-only": html(page(`<title>CHỈNAM</title>`)),
  "/title-superset": html(page(`<title>CHỈNAM — Bàn vận hành (bản cũ)</title>`)),
  "/title-NFD": html(page(MARK.normalize("NFD"))),
  "/title-hyphen-not-emdash": html(page(`<title>CHỈNAM - Bàn vận hành</title>`)),
  "/title-endash": html(page(`<title>CHỈNAM – Bàn vận hành</title>`)),
  "/title-uppercase-tag": html(page(`<TITLE>CHỈNAM — Bàn vận hành</TITLE>`)),
  "/title-with-attribute": html(page(`<title data-rh="true">CHỈNAM — Bàn vận hành</title>`)),
  "/title-extra-spaces": html(page(`<title> CHỈNAM — Bàn vận hành </title>`)),
  "/title-entity-encoded": html(page(`<title>CH&#7880;NAM &mdash; Bàn vận hành</title>`)),
  "/title-nbsp": html(page(`<title>CHỈNAM\u00a0— Bàn vận hành</title>`)),
  // Nhiều thẻ title
  "/two-titles-other-first": html(page(`<title>Trang khác</title>${MARK}`)),
  "/two-titles-marker-first": html(page(`${MARK}<title>Trang khác</title>`)),
  "/two-titles-marker-first-with-script": html(page(`${MARK}<title>x</title><script src="${SRC}" defer></script>`)),
  // Trang lỗi/giữ chỗ của nền tảng hosting chèn title giống app
  "/platform-200-paused-with-marker": html(page(MARK, "This deployment is temporarily paused")),
  "/platform-404-with-marker": html(page(MARK, "404: NOT_FOUND"), 404),
  "/platform-502-with-marker": html(page(MARK, "502: BAD_GATEWAY"), 502),
  "/platform-503-with-marker": html(page(MARK, "503: DEPLOYMENT_PAUSED"), 503),
  "/platform-200-login-wall-plain": html(page(`<title>Login – Vercel</title>`, "Log in to continue")),
  // Đích của chuyển hướng
  "/clean": html(APP()),
  "/with-script": html(APP(`<script src="${SRC}" defer></script>`)),
  "/not-app": html(page(`<title>Trang khác</title>`)),
  // Chuyển hướng cùng origin nhiều bước
  "/r3-clean": redirect("/r3b-clean"), "/r3b-clean": redirect("/r3c-clean", 301), "/r3c-clean": redirect("/clean", 307),
  "/r3-script": redirect("/r3b-script", 308), "/r3b-script": redirect("/r3c-script"), "/r3c-script": redirect("/with-script"),
  "/r3-notapp": redirect("/r3b-notapp"), "/r3b-notapp": redirect("/not-app"),
  "/r-absolute-same-origin": (u) => redirect(`http://127.0.0.1:${A.address().port}/clean`),
  "/r-chain": (u) => { const n = Number(u.searchParams.get("n")); return n > 0 ? redirect(`/r-chain?n=${n - 1}`) : html(APP()); },
  "/r-bounce-via-other-origin": (u) => redirect(`${BASE_C}/back?to=${encodeURIComponent(`http://127.0.0.1:${A.address().port}/clean`)}`),
  // Origin khác chỉ khác cổng / khác host / khác giao thức
  "/r-port-only": redirect(`${BASE_B}/clean`),
  "/r-host-only": redirect(`${BASE_C}/clean`),
  "/r-https-other-port": () => (BASE_D ? redirect(`${BASE_D}/clean`) : html("no https server", 599)),
};
A = await serve(ROUTES);
const BASE = `http://127.0.0.1:${A.address().port}`;
const P = (s) => s.replace(/127\.0\.0\.1:\d+|localhost:\d+|LOCALHOST:\d+/g, (m) => m.split(":")[0] + ":PORT");

function cli(url) {
  return new Promise((ok) => {
    const t0 = Date.now();
    const env = { ...process.env };
    if (CERTS) env.NODE_EXTRA_CA_CERTS = join(CERTS, "cert.pem");
    const child = spawn(process.execPath, [SCRIPT, url], { cwd: H, env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    child.stdout.on("data", (c) => (out += c));
    child.stderr.on("data", (c) => (out += c));
    const kill = setTimeout(() => child.kill("SIGKILL"), 60_000);
    child.on("close", (code) => { clearTimeout(kill); ok({ code, ms: Date.now() - t0, out: out.trim() }); });
  });
}

const rows = [];
const add = (group, label, should, r, extra = "") => {
  const got = r.code === 0 ? "GREEN" : "RED";
  const firstLine = (r.out.split("\n")[0] ?? "");
  const passLineOk = r.code !== 0 || (/^PASS: requested \S+ -> final \S+ -> /.test(firstLine));
  rows.push({ group, label, should, got, code: r.code, ms: r.ms, out: P(firstLine).slice(0, 230), falseGreen: should === "RED" && got === "GREEN", passLineOk, extra });
};

const CLI_CASES = [
  ["marker ngoài <title>", ["/marker-in-comment", "/marker-in-script-string", "/marker-in-attribute", "/marker-in-template", "/marker-in-body-no-head-title"], "RED"],
  ["marker ngoài <title> (đối chứng: đã escape)", ["/marker-html-escaped-in-body"], "RED"],
  ["title khớp một phần / khác chuẩn hoá", ["/title-partial-CHINAM-only", "/title-superset", "/title-NFD", "/title-hyphen-not-emdash", "/title-endash",
    "/title-uppercase-tag", "/title-with-attribute", "/title-extra-spaces", "/title-entity-encoded", "/title-nbsp"], "RED~"],
  ["nhiều thẻ title", ["/two-titles-other-first"], "RED"],
  ["nhiều thẻ title", ["/two-titles-marker-first"], "GREEN"],
  ["nhiều thẻ title", ["/two-titles-marker-first-with-script"], "RED"],
  ["trang nền tảng có title giống app", ["/platform-200-paused-with-marker"], "RED"],
  ["trang nền tảng có title giống app", ["/platform-404-with-marker", "/platform-502-with-marker", "/platform-503-with-marker", "/platform-200-login-wall-plain"], "RED"],
  ["chuyển hướng cùng origin nhiều bước", ["/r3-clean", "/r-absolute-same-origin", "/r-chain?n=19"], "GREEN"],
  ["chuyển hướng cùng origin nhiều bước", ["/r3-script", "/r3-notapp", "/r-chain?n=25"], "RED"],
  ["chuyển hướng cùng origin nhiều bước", ["/r-bounce-via-other-origin"], "?"],
  ["origin khác", ["/r-port-only", "/r-host-only"], "RED"],
];
for (const [group, paths, should] of CLI_CASES) for (const p of paths) add(group, `CLI ${p}`, should, await cli(`${BASE}${p}`));
if (BASE_D) {
  add("origin khác", "CLI http -> https (khác giao thức + cổng)", "RED", await cli(`${BASE}/r-https-other-port`));
  add("origin khác", "CLI https -> http (hạ giao thức, khác cổng)", "RED", await cli(`${BASE_D}/to-http?to=${encodeURIComponent(`${BASE}/clean`)}`));
  add("origin khác (đối chứng)", "CLI https trực tiếp, trang app sạch", "GREEN", await cli(`${BASE_D}/clean`));
}
add("origin khác (đối chứng)", "CLI host viết hoa LOCALHOST, không chuyển hướng", "GREEN", await cli(`${BASE_C.replace("localhost", "LOCALHOST")}/clean`));

// ---- Phần FN: fetchImpl giả, chỉ cho origin khác giao thức cùng cổng và cổng mặc định tường minh
const mod = await import(pathToFileURL(SCRIPT).href);
const fakeFetch = (finalUrl, body = APP(), status = 200) => async () => ({
  status, url: finalUrl, headers: new Headers({ "content-type": "text/html; charset=utf-8" }), text: async () => body,
});
for (const [label, input, finalUrl, should] of [
  ["FN http://h:8443/ -> final https://h:8443/ (chỉ khác giao thức)", "http://h.example:8443/", "https://h.example:8443/", "RED"],
  ["FN https://h/ -> final http://h/ (chỉ khác giao thức, cổng mặc định)", "https://h.example/", "http://h.example/", "RED"],
  ["FN http://h/ -> final http://h:8080/ (chỉ khác cổng)", "http://h.example/", "http://h.example:8080/", "RED"],
  ["FN https://h/ -> final https://h:443/ (cổng mặc định tường minh)", "https://h.example/", "https://h.example:443/x", "GREEN"],
  ["FN https://H.EXAMPLE/ -> final https://h.example/ (khác hoa thường host)", "https://H.EXAMPLE/", "https://h.example/", "GREEN"],
  ["FN https://h/ -> final https://h.example./ (dấu chấm cuối host)", "https://h.example/", "https://h.example./", "RED~"],
  ["FN https://h/ -> final https://user@h.example/ (có userinfo)", "https://h.example/", "https://user@h.example/", "?"],
]) {
  const r = await mod.checkLiveNoGrokExtension(input, { fetchImpl: fakeFetch(finalUrl) });
  rows.push({ group: "origin khác (FN)", label, should, got: r.ok ? "GREEN" : "RED", code: r.ok ? 0 : 1, ms: 0, out: `${r.ok ? "ok" : "fail"}: ${r.reason}`, falseGreen: should === "RED" && r.ok, passLineOk: true });
}

for (const r of rows) {
  console.log(`${r.falseGreen ? "!! XANH SAI" : r.passLineOk ? "   ok      " : "!! PASS-LINE"} | ${r.group.padEnd(44)} | ${r.label.padEnd(66)} | should=${r.should.padEnd(5)} got=${r.got.padEnd(5)} exit=${String(r.code).padEnd(2)} ${String(r.ms).padStart(6)}ms | ${r.out}`);
}
const byGroup = {};
for (const r of rows.filter((x) => x.falseGreen)) byGroup[r.group] = (byGroup[r.group] ?? 0) + 1;
console.log(`TOTAL=${rows.length} FALSE_GREEN=${rows.filter((r) => r.falseGreen).length} BY_GROUP=${JSON.stringify(byGroup)} PASS_LINE_MISSING=${rows.filter((r) => !r.passLineOk).length}`);
for (const s of [A, B, C, D]) { if (s) { s.closeAllConnections?.(); s.close(); } }
