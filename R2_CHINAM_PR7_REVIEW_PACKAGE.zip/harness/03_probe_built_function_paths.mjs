#!/usr/bin/env node
// R2 harness — gọi trực tiếp hàm máy chủ đã build (.vercel/output/functions/__server.func/index.mjs)
// trên nhiều đường dẫn, với VITE_GROK_EXTENSIONS=0 và khi không đặt biến (mỗi trường hợp một tiến trình riêng).
// Mục đích: xem trang gốc "/" có đại diện được cho các trang khác không, và các trang HTML có danh tính
// CHỈNAM (dấu hiệu nhận biết app) hay không. Không sửa mã được chấm.
//
// Cách dùng: node 03_probe_built_function_paths.mjs <.vercel/output>
import { spawnSync } from "node:child_process";
import { existsSync, readdirSync, statSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const NEEDLE = "grok-app-builder/extensions.js";
const outputDir = resolve(process.argv[2] ?? ".vercel/output");
const entry = join(outputDir, "functions/__server.func/index.mjs");
if (!existsSync(entry)) {
  console.error("missing", entry);
  process.exit(1);
}

const PATHS = [
  ["/", "text/html"],
  ["/?utm=1", "text/html"],
  ["/khong-ton-tai-r2", "text/html"],
  ["/index.html", "text/html"],
  ["/?install=1&platform=ios", "text/html"],
  ["/", "*/*"],
  ["/__grok/manifest.webmanifest", "*/*"],
];

const CHILD = `
const mod = await import(process.argv[1]);
const paths = JSON.parse(process.argv[2]);
const out = [];
for (const [p, accept] of paths) {
  const res = await mod.default.fetch(new Request("http://localhost" + p, { headers: { accept } }));
  const body = await res.text();
  const title = (body.match(/<title>([^<]*)<\\/title>/i) || [])[1] ?? null;
  out.push({ path: p, accept, status: res.status, type: res.headers.get("content-type"), bytes: body.length,
    needle: body.includes(${JSON.stringify(NEEDLE)}), title,
    foundationMarker: body.includes("chinam-foundation-v2") });
}
process.stdout.write("\\n" + JSON.stringify(out));
`;

function probe(flag) {
  const env = { ...process.env };
  delete env.VITE_GROK_EXTENSIONS;
  if (flag !== undefined) env.VITE_GROK_EXTENSIONS = flag;
  const r = spawnSync(process.execPath, ["--input-type=module", "-e", CHILD, pathToFileURL(entry).href, JSON.stringify(PATHS)], { env, encoding: "utf8", timeout: 60_000 });
  if (r.status !== 0) throw new Error(`child exit ${r.status}: ${r.stderr}`);
  return JSON.parse(r.stdout.trim().split("\n").at(-1));
}

function listHtml(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) listHtml(p, acc);
    else if (/\.html?$/i.test(name)) acc.push(p.slice(outputDir.length));
  }
  return acc;
}

console.log("static HTML files in output:", JSON.stringify(listHtml(join(outputDir, "static"))));
for (const flag of ["0", undefined, "false", "", " 0 "]) {
  const label = flag === undefined ? "UNSET" : JSON.stringify(flag);
  for (const row of probe(flag)) {
    console.log(
      `VITE_GROK_EXTENSIONS=${label.padEnd(6)} ${row.path.padEnd(30)} accept=${row.accept.padEnd(9)} ` +
        `status=${row.status} type=${row.type} bytes=${row.bytes} needle=${row.needle ? "PRESENT" : "ABSENT"} ` +
        `title=${JSON.stringify(row.title)} chinam-foundation-v2=${row.foundationMarker}`,
    );
  }
}
