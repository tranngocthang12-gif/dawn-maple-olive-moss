R2 vòng 2: địa chỉ IP ra ngoài của sandbox trong phản hồi 403 của api.github.com đã được thay bằng <IP-sandbox-đã-che> trước khi đóng gói (gói sẽ công khai). Không thay đổi gì khác.
