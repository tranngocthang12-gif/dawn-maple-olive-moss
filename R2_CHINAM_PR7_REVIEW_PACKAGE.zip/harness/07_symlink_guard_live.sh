#!/usr/bin/env bash
# R2 harness — guard cuối tệp `if (import.meta.url === pathToFileURL(process.argv[1] ?? "").href) await main();`
# của scripts/check-live-no-grok-extension.mjs (H). Node lấy import.meta.url theo realpath, còn
# process.argv[1] chỉ là path.resolve (không realpath). Gọi bằng đường dẫn tuyệt đối đi qua symlink
# => main() không chạy => thoát 0, không in gì, kể cả khi trang CÓ script.
# Cách dùng: bash 07_symlink_guard_live.sh <checkout H> <thư mục làm việc>
set -u
H="$(cd "$1" && pwd -P)"; WORK="$2"
rm -rf "$WORK" && mkdir -p "$WORK" && ln -s "$H" "$WORK/H_link"
cat >"$WORK/srv.mjs" <<'EOF'
import { createServer } from "node:http";
const s = createServer((q, r) => { r.writeHead(200, { "content-type": "text/html" });
  r.end('<html><head><script src="https://grok.com/grok-app-builder/extensions.js" defer></script></head></html>'); });
s.listen(0, "127.0.0.1", () => { console.log(s.address().port); });
setTimeout(() => s.close(), 15000);
EOF
node "$WORK/srv.mjs" >"$WORK/port" & SRV=$!
for _ in $(seq 1 50); do [ -s "$WORK/port" ] && break; sleep 0.1; done
URL="http://127.0.0.1:$(cat "$WORK/port")/"
show() { local label="$1"; shift; local out rc; out="$("$@" 2>&1)"; rc=$?; echo "=== $label"; echo "[output ${#out} byte] $(printf "%s" "$out" | sed -E "s/127\.0\.0\.1:[0-9]+/127.0.0.1:PORT/g")"; echo "EXIT=$rc"; }
show "đường dẫn thật, trang CÓ script"                       node "$H/scripts/check-live-no-grok-extension.mjs" "$URL"
show "đường dẫn tuyệt đối qua symlink, CÙNG trang"            node "$WORK/H_link/scripts/check-live-no-grok-extension.mjs" "$URL"
show "qua symlink + --preserve-symlinks-main"                 node --preserve-symlinks-main "$WORK/H_link/scripts/check-live-no-grok-extension.mjs" "$URL"
show "cd vào symlink, đường dẫn tương đối"                    bash -c "cd '$WORK/H_link' && node scripts/check-live-no-grok-extension.mjs '$URL'"
kill "$SRV" 2>/dev/null; wait 2>/dev/null
